import defaultTheme from 'tailwindcss/defaultTheme';

export default {
  content: ['./index.html', './src/**/*.{js,jsx}'],
  theme: {
    extend: {
      colors: {
        ink: '#17181C',
        chalk: '#F6F4EF',
        bottega: '#1F4D3A',
        brass: '#B08D57',
        rosewood: '#8B4A45',
        mist: '#E4E1D8',
      },
      fontFamily: {
        display: ['Vazirmatn', ...defaultTheme.fontFamily.sans],
        body: ['Vazirmatn', ...defaultTheme.fontFamily.sans],
        mono: ['Vazirmatn', ...defaultTheme.fontFamily.mono],
      },
      container: {
        center: true,
        padding: { DEFAULT: '1rem', sm: '1.5rem', md: '2rem', lg: '3rem' },
      },
    },
  },
  plugins: [],
};
