import { useContext, useState } from 'react';
import { useParams } from 'react-router-dom';
import { PRODUCTS } from '@/data/products';
import { CartContext } from '@/context/CartContext';
import { WishlistContext } from '@/context/WishlistContext';
import { StarIcon, HeartIcon } from '@/components/ui/icons';
import Button from '@/components/ui/Button';

export default function ProductDetail() {
  const { slug } = useParams();
  const product = PRODUCTS.find((p) => p.slug === slug);
  const [selectedColor, setSelectedColor] = useState(product?.colors?.[0]);
  const [selectedSize, setSelectedSize] = useState(product?.sizes?.[0]);
  const [quantity, setQuantity] = useState(1);
  const [imageIndex, setImageIndex] = useState(0);

  const { addToCart } = useContext(CartContext);
  const { isInWishlist, toggleWishlist } = useContext(WishlistContext);

  if (!product) {
    return <div className="min-h-screen flex items-center justify-center">محصول یافت نشد</div>;
  }

  const price = product.discountPrice || product.price;
  const discount = product.discountPrice
    ? Math.round(((product.price - product.discountPrice) / product.price) * 100)
    : 0;

  const handleAddToCart = () => {
    addToCart(product, quantity, selectedColor, selectedSize);
    alert('محصول به سبد خرید اضافه شد');
  };

  return (
    <div className="min-h-screen bg-chalk py-10">
      <div className="container max-w-6xl">
        <div className="grid grid-cols-1 gap-10 md:grid-cols-2">
          {/* عکس */}
          <div>
            <div className="relative aspect-square overflow-hidden bg-mist mb-4">
              <img
                src={product.images?.[imageIndex]}
                alt={product.name}
                className="h-full w-full object-cover"
              />
              {discount > 0 && (
                <div className="absolute top-4 left-4 bg-rosewood text-chalk px-3 py-1 text-sm font-bold">
                  {discount}% تخفیف
                </div>
              )}
            </div>
            <div className="flex gap-2">
              {product.images?.map((img, idx) => (
                <button
                  key={idx}
                  onClick={() => setImageIndex(idx)}
                  className={`h-16 w-16 border-2 ${
                    idx === imageIndex ? 'border-bottega' : 'border-transparent'
                  }`}
                >
                  <img src={img} alt="" className="h-full w-full object-cover" />
                </button>
              ))}
            </div>
          </div>

          {/* اطلاعات */}
          <div>
            <p className="text-sm text-ink/60">{product.brand}</p>
            <h1 className="font-display text-3xl mt-2">{product.name}</h1>
            <p className="text-lg mt-4">{product.caption}</p>

            {/* امتیاز */}
            <div className="flex items-center gap-2 mt-4">
              <div className="flex gap-0.5">
                {[...Array(5)].map((_, i) => (
                  <StarIcon
                    key={i}
                    width={16}
                    height={16}
                    fill="currentColor"
                    className={i < Math.round(product.rating) ? 'text-brass' : 'text-ink/20'}
                  />
                ))}
              </div>
              <span className="text-sm text-ink/60">
                {product.rating} ({product.reviews} نظر)
              </span>
            </div>

            {/* قیمت */}
            <div className="flex items-center gap-4 mt-6">
              <span className="font-display text-3xl">{price.toLocaleString('fa-IR')} تومان</span>
              {product.discountPrice && (
                <span className="line-through text-ink/50">
                  {product.price.toLocaleString('fa-IR')} تومان
                </span>
              )}
            </div>

            {/* رنگ‌ها */}
            {product.colors?.length > 0 && (
              <div className="mt-6">
                <p className="text-sm font-bold mb-2">رنگ:</p>
                <div className="flex gap-3">
                  {product.colors.map((color) => (
                    <button
                      key={color}
                      onClick={() => setSelectedColor(color)}
                      className={`w-10 h-10 rounded-full border-2 ${
                        selectedColor === color ? 'border-ink' : 'border-transparent'
                      }`}
                      style={{ backgroundColor: color }}
                    />
                  ))}
                </div>
              </div>
            )}

            {/* سایز‌ها */}
            {product.sizes?.length > 0 && (
              <div className="mt-6">
                <p className="text-sm font-bold mb-2">سایز:</p>
                <div className="flex flex-wrap gap-2">
                  {product.sizes.map((size) => (
                    <button
                      key={size}
                      onClick={() => setSelectedSize(size)}
                      className={`px-4 py-2 border-2 ${
                        selectedSize === size
                          ? 'border-ink bg-ink text-chalk'
                          : 'border-ink/20 hover:border-ink'
                      }`}
                    >
                      {size}
                    </button>
                  ))}
                </div>
              </div>
            )}

            {/* تعداد */}
            <div className="mt-6 flex items-center gap-4">
              <p className="text-sm font-bold">تعداد:</p>
              <div className="flex items-center border border-ink/20">
                <button
                  onClick={() => setQuantity(Math.max(1, quantity - 1))}
                  className="px-3 py-2 hover:bg-ink/5"
                >
                  −
                </button>
                <span className="px-4 py-2">{quantity}</span>
                <button
                  onClick={() => setQuantity(quantity + 1)}
                  className="px-3 py-2 hover:bg-ink/5"
                >
                  +
                </button>
              </div>
            </div>

            {/* دکمه‌ها */}
            <div className="flex gap-4 mt-8">
              <Button variant="primary" onClick={handleAddToCart} className="flex-1">
                افزودن به سبد خرید
              </Button>
              <button
                onClick={() => toggleWishlist(product)}
                className={`p-3 border-2 ${
                  isInWishlist(product.id)
                    ? 'border-rosewood text-rosewood'
                    : 'border-ink/20 hover:border-rosewood hover:text-rosewood'
                }`}
              >
                <HeartIcon width={20} height={20} fill="currentColor" />
              </button>
            </div>

            {/* توضیحات */}
            <div className="mt-10 pt-10 border-t border-ink/10">
              <h3 className="font-bold text-lg mb-4">توضیحات محصول</h3>
              <p className="text-sm leading-relaxed text-ink/70">{product.description}</p>
            </div>

            {/* موجود بودن */}
            <div className="mt-6 p-4 bg-bottega/10 rounded">
              <p className="text-sm">
                {product.stock > 0 ? (
                  <span className="text-bottega font-bold">موجود در انبار ({product.stock} عدد)</span>
                ) : (
                  <span className="text-rosewood font-bold">ناموجود</span>
                )}
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
