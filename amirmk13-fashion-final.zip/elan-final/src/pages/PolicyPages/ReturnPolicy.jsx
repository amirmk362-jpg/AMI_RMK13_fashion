export default function ReturnPolicy() {
  return (
    <div className="min-h-screen bg-chalk py-10">
      <div className="container max-w-3xl">
        <h1 className="font-display text-4xl mb-10">سیاست برگشت و استرجاع</h1>
        <div className="space-y-8 text-ink">
          <section>
            <h2 className="font-bold text-2xl mb-4">۳۰ روز ضمانت برگشت</h2>
            <p className="text-ink/80 leading-relaxed">هر خریدی را می‌توانید تا ۳۰ روز پس از دریافت محصول برگشت دهید و مبلغ کامل پس گیرید.</p>
          </section>
          <section>
            <h2 className="font-bold text-2xl mb-4">شرایط برگشت</h2>
            <ul className="list-disc list-inside space-y-3 text-ink/80">
              <li>محصول باید در شرایط اصلی و استفاده‌نشده باشد</li>
              <li>برچسب قیمت اصلی باید دست‌نخورده باشد</li>
              <li>هیچ علامت استفاده یا آسیب روی محصول نباید باشد</li>
              <li>جعبه اصلی و تمام مواد بسته‌بندی سالم باشد</li>
              <li>فاکتور و رسید خرید باید همراه باشد</li>
            </ul>
          </section>
          <section>
            <h2 className="font-bold text-2xl mb-4">فرآیند برگشت</h2>
            <ol className="list-decimal list-inside space-y-3 text-ink/80">
              <li>درخواست برگشت را از صفحه حساب کاربری ثبت کنید</li>
              <li>برچسب پستی رایگان را چاپ کنید</li>
              <li>محصول را به آدرس انبار بفرستید</li>
              <li>پس از دریافت و بررسی، بازپرداخت ۲۴ ساعته انجام می‌شود</li>
            </ol>
          </section>
          <section>
            <h2 className="font-bold text-2xl mb-4">هزینه ارسال</h2>
            <p className="text-ink/80 leading-relaxed">ما هزینه ارسال برگشت را می‌پردازیم اگر محصول معیوب، نادرست، یا با شرح متفاوت باشد.</p>
          </section>
          <section>
            <h2 className="font-bold text-2xl mb-4">استثناءات</h2>
            <p className="text-ink/80 leading-relaxed">برخی محصولات شامل حق برگشت ندارند: لباس زیر، جوراب، و محصولات بهداشتی.</p>
          </section>
        </div>
      </div>
    </div>
  );
}
