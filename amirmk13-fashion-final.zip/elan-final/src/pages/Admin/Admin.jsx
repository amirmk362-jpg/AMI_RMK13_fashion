import { useState } from 'react';

export default function Admin() {
  const [tab, setTab] = useState('dashboard');

  return (
    <div className="min-h-screen bg-chalk">
      <div className="flex">
        {/* Sidebar */}
        <div className="w-64 bg-ink text-chalk p-6 min-h-screen">
          <h2 className="font-display text-2xl mb-8">امیرام کالا</h2>
          <nav className="space-y-2">
            {['dashboard', 'products', 'orders', 'users', 'analytics'].map((t) => (
              <button key={t} onClick={() => setTab(t)} className={`block w-full text-right py-2 px-4 rounded ${tab === t ? 'bg-bottega' : 'hover:bg-ink/50'}`}>
                {t === 'dashboard' ? '📊 داشبورد' : t === 'products' ? '📦 محصولات' : t === 'orders' ? '📋 سفارشات' : t === 'users' ? '👥 کاربران' : '📈 تحلیلات'}
              </button>
            ))}
          </nav>
        </div>

        {/* Content */}
        <div className="flex-1 p-8">
          {tab === 'dashboard' && (
            <div>
              <h1 className="font-display text-3xl mb-10">داشبورد</h1>
              <div className="grid grid-cols-4 gap-6 mb-10">
                {[
                  { label: 'فروش', value: '۲۳۴۵۶۷ تومان' },
                  { label: 'سفارشات', value: '۱۲۳' },
                  { label: 'محصولات', value: '۶۰' },
                  { label: 'کاربران', value: '۴۵۶' }
                ].map((stat, i) => (
                  <div key={i} className="p-6 border-2 border-bottega rounded">
                    <p className="text-sm text-ink/60 mb-2">{stat.label}</p>
                    <p className="font-display text-2xl">{stat.value}</p>
                  </div>
                ))}
              </div>
            </div>
          )}

          {tab === 'products' && (
            <div>
              <h1 className="font-display text-3xl mb-10">مدیریت محصولات</h1>
              <button className="px-6 py-3 bg-bottega text-chalk rounded font-bold mb-6">+ افزودن محصول جدید</button>
              <table className="w-full border-collapse border border-ink/20">
                <thead>
                  <tr className="bg-ink/5">
                    <th className="border border-ink/20 p-3 text-right">نام</th>
                    <th className="border border-ink/20 p-3 text-right">قیمت</th>
                    <th className="border border-ink/20 p-3 text-right">موجودی</th>
                    <th className="border border-ink/20 p-3">عملیات</th>
                  </tr>
                </thead>
              </table>
            </div>
          )}

          {tab === 'orders' && (
            <div>
              <h1 className="font-display text-3xl mb-10">سفارشات</h1>
              <div className="text-center text-ink/60 py-20">لیست سفارشات خالی است</div>
            </div>
          )}

          {tab === 'users' && (
            <div>
              <h1 className="font-display text-3xl mb-10">کاربران</h1>
              <div className="text-center text-ink/60 py-20">لیست کاربران خالی است</div>
            </div>
          )}

          {tab === 'analytics' && (
            <div>
              <h1 className="font-display text-3xl mb-10">تحلیلات</h1>
              <div className="text-center text-ink/60 py-20">داده‌های تحلیلی در دسترس نیست</div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
