import { useState } from 'react';
import Button from '@/components/ui/Button';

export default function Account() {
  const [tab, setTab] = useState('profile');
  const [user, setUser] = useState({ name: 'محمد', email: 'user@example.com', phone: '09123456789' });

  return (
    <div className="min-h-screen bg-chalk py-10">
      <div className="container max-w-4xl">
        <h1 className="font-display text-3xl mb-10">حساب کاربری</h1>

        <div className="grid grid-cols-1 gap-8 md:grid-cols-4">
          <div className="space-y-2">
            {['profile', 'orders', 'wishlist', 'addresses'].map((t) => (
              <button key={t} onClick={() => setTab(t)} className={`block w-full text-right py-2 px-3 rounded ${tab === t ? 'bg-bottega text-chalk' : 'hover:bg-ink/5'}`}>
                {t === 'profile' ? 'پروفایل' : t === 'orders' ? 'سفارشات' : t === 'wishlist' ? 'علاقه‌مندی‌ها' : 'آدرس‌ها'}
              </button>
            ))}
          </div>

          <div className="md:col-span-3 p-6 border border-ink/10 rounded">
            {tab === 'profile' && (
              <div className="space-y-4">
                <h2 className="font-bold text-lg mb-6">اطلاعات شخصی</h2>
                <input type="text" value={user.name} placeholder="نام" className="w-full p-3 border border-ink/20 rounded" onChange={(e) => setUser({...user, name: e.target.value})} />
                <input type="email" value={user.email} placeholder="ایمیل" className="w-full p-3 border border-ink/20 rounded" onChange={(e) => setUser({...user, email: e.target.value})} />
                <input type="tel" value={user.phone} placeholder="تلفن" className="w-full p-3 border border-ink/20 rounded" onChange={(e) => setUser({...user, phone: e.target.value})} />
                <Button variant="primary">ذخیره تغییرات</Button>
              </div>
            )}

            {tab === 'orders' && (
              <div>
                <h2 className="font-bold text-lg mb-6">سفارشات من</h2>
                <div className="text-center text-ink/60 py-10">هنوز سفارشی ثبت نشده</div>
              </div>
            )}

            {tab === 'wishlist' && (
              <div>
                <h2 className="font-bold text-lg mb-6">علاقه‌مندی‌ها</h2>
                <div className="text-center text-ink/60 py-10">لیست علاقه‌مندی‌ها خالی است</div>
              </div>
            )}

            {tab === 'addresses' && (
              <div>
                <h2 className="font-bold text-lg mb-6">آدرس‌های من</h2>
                <Button variant="primary">افزودن آدرس جدید</Button>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
