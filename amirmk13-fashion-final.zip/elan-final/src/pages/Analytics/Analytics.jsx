import { AnalyticsService } from '@/services/AnalyticsService';

export default function Analytics() {
  const stats = {
    visitors: Math.floor(Math.random() * 10000) + 1000,
    sales: Math.floor(Math.random() * 100) + 50,
    conversion: (Math.random() * 5 + 2).toFixed(2)
  };

  return (
    <div className="min-h-screen bg-chalk py-10">
      <div className="container">
        <h1 className="font-display text-3xl mb-10">تحلیلات</h1>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="p-6 border border-ink/10 rounded">
            <p className="text-ink/60 text-sm">بازدید‌کننده</p>
            <p className="font-display text-3xl mt-2">{stats.visitors.toLocaleString('fa-IR')}</p>
          </div>
          <div className="p-6 border border-ink/10 rounded">
            <p className="text-ink/60 text-sm">فروش</p>
            <p className="font-display text-3xl mt-2">{stats.sales}</p>
          </div>
          <div className="p-6 border border-ink/10 rounded">
            <p className="text-ink/60 text-sm">درصد تبدیل</p>
            <p className="font-display text-3xl mt-2">{stats.conversion}%</p>
          </div>
        </div>
      </div>
    </div>
  );
}
