import { useState, useMemo } from 'react';
import { useSearchParams } from 'react-router-dom';
import { PRODUCTS } from '@/data/products';
import ProductCard from '@/components/ui/ProductCard';

export default function Search() {
  const [searchParams] = useSearchParams();
  const query = searchParams.get('q') || '';
  const [searchInput, setSearchInput] = useState(query);

  const results = useMemo(() => {
    if (!searchInput.trim()) return [];
    return PRODUCTS.filter((p) =>
      p.name.includes(searchInput) ||
      p.brand.includes(searchInput) ||
      p.category.includes(searchInput) ||
      p.description.includes(searchInput)
    );
  }, [searchInput]);

  return (
    <div className="min-h-screen bg-chalk py-10">
      <div className="container">
        <h1 className="font-display text-3xl mb-10">جستجو</h1>

        <div className="mb-10">
          <input
            type="text"
            value={searchInput}
            onChange={(e) => setSearchInput(e.target.value)}
            placeholder="جستجو کردن..."
            className="w-full p-4 border-2 border-bottega rounded text-lg"
          />
        </div>

        {searchInput && (
          <div className="mb-6 text-sm text-ink/60">
            {results.length} محصول یافت شد
          </div>
        )}

        {results.length > 0 ? (
          <div className="grid grid-cols-2 gap-6 sm:grid-cols-3 lg:grid-cols-4">
            {results.map((product) => (
              <div key={product.id}>
                <ProductCard product={product} />
              </div>
            ))}
          </div>
        ) : searchInput ? (
          <div className="text-center py-20 text-ink/60">
            محصولی با این عنوان یافت نشد
          </div>
        ) : (
          <div className="text-center py-20 text-ink/60">
            یک عبارت را برای جستجو وارد کنید
          </div>
        )}
      </div>
    </div>
  );
}
