import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import Button from '@/components/ui/Button';

export default function Login() {
  const [form, setForm] = useState({ email: '', password: '' });
  const navigate = useNavigate();

  const handleSubmit = (e) => {
    e.preventDefault();
    if (form.email && form.password) {
      localStorage.setItem('user', JSON.stringify({ email: form.email, name: 'کاربر' }));
      navigate('/account');
    }
  };

  return (
    <div className="min-h-screen bg-chalk py-10 flex items-center">
      <div className="container max-w-md">
        <div className="p-8 border border-ink/10 rounded-lg">
          <h1 className="font-display text-3xl mb-8 text-center">ورود</h1>
          <form onSubmit={handleSubmit} className="space-y-4">
            <input type="email" placeholder="ایمیل" value={form.email} onChange={(e) => setForm({...form, email: e.target.value})} className="w-full p-3 border border-ink/20 rounded" required />
            <input type="password" placeholder="رمز عبور" value={form.password} onChange={(e) => setForm({...form, password: e.target.value})} className="w-full p-3 border border-ink/20 rounded" required />
            <Button type="submit" variant="primary" className="w-full">ورود</Button>
          </form>
          <p className="text-center text-sm mt-6">حساب ندارید؟ <Link to="/register" className="text-bottega font-bold">ثبت‌نام</Link></p>
        </div>
      </div>
    </div>
  );
}
