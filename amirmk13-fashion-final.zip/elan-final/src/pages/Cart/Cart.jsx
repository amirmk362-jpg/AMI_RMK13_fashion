import { useContext } from 'react';
import { Link } from 'react-router-dom';
import { CartContext } from '@/context/CartContext';
import Button from '@/components/ui/Button';

export default function Cart() {
  const { cart, removeFromCart, updateQuantity, total } = useContext(CartContext);

  if (cart.length === 0) {
    return (
      <div className="min-h-screen bg-chalk py-20">
        <div className="container text-center">
          <h1 className="font-display text-3xl mb-4">سبد خرید خالی است</h1>
          <p className="text-ink/60 mb-8">هنوز محصولی به سبد خرید اضافه نکردید</p>
          <Link to="/shop">
            <Button variant="primary">برو به فروشگاه</Button>
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-chalk py-10">
      <div className="container max-w-4xl">
        <h1 className="font-display text-3xl mb-10">سبد خرید</h1>

        <div className="grid grid-cols-1 gap-8 md:grid-cols-3">
          <div className="md:col-span-2 space-y-4">
            {cart.map((item) => (
              <div key={item.cartItemId} className="flex gap-4 p-4 border border-ink/10 rounded">
                <img src={item.images?.[0]} alt={item.name} className="h-24 w-24 object-cover" />
                <div className="flex-1">
                  <h3 className="font-bold">{item.name}</h3>
                  <p className="text-sm text-ink/60">{item.brand}</p>
                  {item.color && <p className="text-xs text-ink/50 mt-1">رنگ: {item.color}</p>}
                  {item.size && <p className="text-xs text-ink/50">سایز: {item.size}</p>}
                  <p className="font-bold mt-2">{(item.discountPrice || item.price).toLocaleString('fa-IR')} تومان</p>
                </div>
                <div className="flex flex-col items-end gap-2">
                  <div className="flex items-center gap-2">
                    <button onClick={() => updateQuantity(item.cartItemId, item.quantity - 1)} className="px-2 py-1 border">−</button>
                    <span className="px-2">{item.quantity}</span>
                    <button onClick={() => updateQuantity(item.cartItemId, item.quantity + 1)} className="px-2 py-1 border">+</button>
                  </div>
                  <button onClick={() => removeFromCart(item.cartItemId)} className="text-rosewood hover:text-rosewood/80 text-sm font-bold">
                    حذف
                  </button>
                </div>
              </div>
            ))}
          </div>

          <div className="h-fit p-6 border border-ink/10 rounded">
            <h3 className="font-bold text-lg mb-4">خلاصه سفارش</h3>
            <div className="space-y-2 text-sm border-b border-ink/10 pb-4 mb-4">
              <div className="flex justify-between">
                <span>جمع:</span>
                <span>{total.toLocaleString('fa-IR')} تومان</span>
              </div>
              <div className="flex justify-between">
                <span>هزینه ارسال:</span>
                <span>رایگان</span>
              </div>
            </div>
            <div className="flex justify-between font-bold text-lg mb-6">
              <span>مجموع:</span>
              <span>{total.toLocaleString('fa-IR')} تومان</span>
            </div>
            <Link to="/checkout" className="block w-full">
              <Button variant="primary" className="w-full">
                تکمیل خرید
              </Button>
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
}
