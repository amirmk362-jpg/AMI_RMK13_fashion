import { useContext, useState } from 'react';
import { CartContext } from '@/context/CartContext';
import { CouponContext } from '@/context/CouponContext';
import Button from '@/components/ui/Button';

export default function Checkout() {
  const { cart, total, clearCart } = useContext(CartContext);
  const { appliedCoupon, applyCoupon, removeCoupon } = useContext(CouponContext);
  const [step, setStep] = useState(1);
  const [couponCode, setCouponCode] = useState('');
  const [formData, setFormData] = useState({
    firstName: '', lastName: '', email: '', phone: '',
    address: '', city: '', zipCode: '',
    paymentMethod: 'card'
  });

  const discountAmount = appliedCoupon ? (total * appliedCoupon.discount) / 100 : 0;
  const finalTotal = total - discountAmount;

  const handleApplyCoupon = () => {
    const result = applyCoupon(couponCode);
    alert(result.message);
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (step < 3) {
      setStep(step + 1);
    } else {
      alert('سفارش شما ثبت شد! شماره پیگیری: #' + Math.random().toString(36).substr(2, 9).toUpperCase());
      clearCart();
      window.location.href = '/';
    }
  };

  if (cart.length === 0) {
    return <div className="min-h-screen bg-chalk py-20 text-center"><p>سبد خرید خالی است</p></div>;
  }

  return (
    <div className="min-h-screen bg-chalk py-10">
      <div className="container max-w-4xl">
        <h1 className="font-display text-3xl mb-10">تکمیل خرید</h1>

        <div className="flex justify-between mb-10">
          {[1, 2, 3].map((s) => (
            <div key={s} className="flex-1 text-center">
              <div className={`h-10 w-10 rounded-full mx-auto mb-2 flex items-center justify-center font-bold ${s <= step ? 'bg-bottega text-chalk' : 'bg-ink/10'}`}>{s}</div>
              <p className="text-sm">{s === 1 ? 'آدرس' : s === 2 ? 'پرداخت' : 'تایید'}</p>
            </div>
          ))}
        </div>

        <div className="grid grid-cols-1 gap-8 md:grid-cols-3">
          <div className="md:col-span-2">
            <form onSubmit={handleSubmit} className="space-y-4">
              {step === 1 && (
                <>
                  <input type="text" placeholder="نام" value={formData.firstName} onChange={(e) => setFormData({...formData, firstName: e.target.value})} className="w-full p-3 border border-ink/20 rounded" required />
                  <input type="text" placeholder="نام خانوادگی" value={formData.lastName} onChange={(e) => setFormData({...formData, lastName: e.target.value})} className="w-full p-3 border border-ink/20 rounded" required />
                  <input type="email" placeholder="ایمیل" value={formData.email} onChange={(e) => setFormData({...formData, email: e.target.value})} className="w-full p-3 border border-ink/20 rounded" required />
                  <input type="tel" placeholder="شماره تلفن" value={formData.phone} onChange={(e) => setFormData({...formData, phone: e.target.value})} className="w-full p-3 border border-ink/20 rounded" required />
                  <textarea placeholder="آدرس" value={formData.address} onChange={(e) => setFormData({...formData, address: e.target.value})} className="w-full p-3 border border-ink/20 rounded" required rows={3}></textarea>
                  <div className="grid grid-cols-2 gap-4">
                    <input type="text" placeholder="شهر" value={formData.city} onChange={(e) => setFormData({...formData, city: e.target.value})} className="w-full p-3 border border-ink/20 rounded" required />
                    <input type="text" placeholder="کد پستی" value={formData.zipCode} onChange={(e) => setFormData({...formData, zipCode: e.target.value})} className="w-full p-3 border border-ink/20 rounded" required />
                  </div>
                </>
              )}

              {step === 2 && (
                <>
                  <div className="space-y-3">
                    {['card', 'bank', 'wallet'].map((method) => (
                      <label key={method} className="flex items-center p-3 border border-ink/20 rounded cursor-pointer">
                        <input type="radio" name="payment" value={method} checked={formData.paymentMethod === method} onChange={(e) => setFormData({...formData, paymentMethod: e.target.value})} />
                        <span className="mr-3">{method === 'card' ? 'کارت اعتباری' : method === 'bank' ? 'تراف‌بانکی' : 'کیف پول دیجیتال'}</span>
                      </label>
                    ))}
                  </div>
                </>
              )}

              {step === 3 && (
                <div className="p-4 bg-bottega/10 rounded">
                  <p className="mb-2"><strong>نام:</strong> {formData.firstName} {formData.lastName}</p>
                  <p className="mb-2"><strong>آدرس:</strong> {formData.address}, {formData.city}</p>
                  <p><strong>روش پرداخت:</strong> {formData.paymentMethod}</p>
                </div>
              )}

              <Button type="submit" variant="primary" className="w-full">{step < 3 ? 'بعدی' : 'تایید و پرداخت'}</Button>
            </form>
          </div>

          <div className="h-fit p-6 border border-ink/10 rounded">
            <h3 className="font-bold mb-4">خلاصه سفارش</h3>
            
            {step === 2 && (
              <div className="mb-4 p-3 border border-ink/20 rounded">
                <input type="text" placeholder="کد تخفیف" value={couponCode} onChange={(e) => setCouponCode(e.target.value)} className="w-full p-2 border border-ink/20 rounded text-sm mb-2" />
                <button onClick={handleApplyCoupon} className="w-full bg-bottega text-chalk py-2 rounded text-sm">اعمال کد</button>
                {appliedCoupon && (
                  <div className="mt-2 p-2 bg-bottega/20 rounded text-sm">
                    <p className="text-bottega font-bold">{appliedCoupon.name}</p>
                    <button onClick={removeCoupon} className="text-xs text-rosewood mt-1">حذف</button>
                  </div>
                )}
              </div>
            )}

            <div className="space-y-2 text-sm border-b border-ink/10 pb-4 mb-4 max-h-48 overflow-y-auto">
              {cart.map((item) => (
                <div key={item.cartItemId} className="flex justify-between">
                  <span>{item.name} × {item.quantity}</span>
                  <span>{((item.discountPrice || item.price) * item.quantity).toLocaleString('fa-IR')}</span>
                </div>
              ))}
            </div>

            <div className="space-y-2 text-sm mb-4">
              <div className="flex justify-between">
                <span>مجموع:</span>
                <span>{total.toLocaleString('fa-IR')} تومان</span>
              </div>
              {appliedCoupon && (
                <div className="flex justify-between text-rosewood">
                  <span>تخفیف ({appliedCoupon.discount}%):</span>
                  <span>-{discountAmount.toLocaleString('fa-IR')} تومان</span>
                </div>
              )}
              <div className="flex justify-between font-bold text-lg pt-2 border-t border-ink/10">
                <span>پرداخت نهایی:</span>
                <span>{finalTotal.toLocaleString('fa-IR')} تومان</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
