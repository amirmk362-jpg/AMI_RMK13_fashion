// Page-level route components (Home, ProductDetail, Checkout, Account, Admin...) are added as the project grows.
