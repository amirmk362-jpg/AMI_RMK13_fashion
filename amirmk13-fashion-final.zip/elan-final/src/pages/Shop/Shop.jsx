import { useState, useMemo } from 'react';
import { PRODUCTS, getProductsByCategory } from '@/data/products';
import ProductCard from '@/components/ui/ProductCard';
import { ChevronDownIcon } from '@/components/ui/icons';

const CATEGORIES = [
  'T-Shirts', 'Hoodies', 'Shirts', 'Jeans', 'Jackets',
  'Sneakers', 'Watches', 'Accessories', 'Sportswear', 'Formal Wear'
];

const SORT_OPTIONS = [
  { label: 'جدیدترین', value: 'newest' },
  { label: 'محبوب‌ترین', value: 'popular' },
  { label: 'کم‌ترین قیمت', value: 'price-asc' },
  { label: 'بیش‌ترین قیمت', value: 'price-desc' },
];

export default function Shop() {
  const [selectedCategory, setSelectedCategory] = useState('All');
  const [selectedSort, setSelectedSort] = useState('newest');
  const [priceRange, setPriceRange] = useState([0, 1000000]);

  const filtered = useMemo(() => {
    let result = selectedCategory === 'All' 
      ? PRODUCTS 
      : getProductsByCategory(selectedCategory);

    // فیلتر قیمت
    result = result.filter((p) => {
      const price = p.discountPrice || p.price;
      return price >= priceRange[0] && price <= priceRange[1];
    });

    // مرتب‌سازی
    const sorted = [...result].sort((a, b) => {
      const aPrice = a.discountPrice || a.price;
      const bPrice = b.discountPrice || b.price;

      switch (selectedSort) {
        case 'price-asc':
          return aPrice - bPrice;
        case 'price-desc':
          return bPrice - aPrice;
        case 'popular':
          return b.rating - a.rating;
        case 'newest':
        default:
          return b.newArrival ? 1 : -1;
      }
    });

    return sorted;
  }, [selectedCategory, selectedSort, priceRange]);

  return (
    <div className="min-h-screen bg-chalk py-10">
      <div className="container">
        <h1 className="font-display text-4xl mb-10">فروشگاه</h1>

        <div className="grid grid-cols-1 gap-8 md:grid-cols-4">
          {/* فیلتر‌ها */}
          <div className="md:col-span-1">
            <div className="sticky top-20">
              {/* دسته‌بندی */}
              <div className="mb-8">
                <h3 className="font-bold mb-4">دسته‌بندی</h3>
                <div className="space-y-2">
                  {['All', ...CATEGORIES].map((cat) => (
                    <button
                      key={cat}
                      onClick={() => setSelectedCategory(cat)}
                      className={`block w-full text-right py-2 px-3 rounded transition ${
                        selectedCategory === cat
                          ? 'bg-bottega text-chalk'
                          : 'hover:bg-chalk border border-ink/10'
                      }`}
                    >
                      {cat === 'All' ? 'همه محصولات' : cat}
                    </button>
                  ))}
                </div>
              </div>

              {/* قیمت */}
              <div className="mb-8">
                <h3 className="font-bold mb-4">محدوده قیمت</h3>
                <input
                  type="range"
                  min="0"
                  max="1000000"
                  step="10000"
                  value={priceRange[1]}
                  onChange={(e) => setPriceRange([priceRange[0], parseInt(e.target.value)])}
                  className="w-full"
                />
                <p className="text-sm mt-2 text-ink/70">
                  تا {priceRange[1].toLocaleString('fa-IR')} تومان
                </p>
              </div>

              {/* مرتب‌سازی */}
              <div>
                <h3 className="font-bold mb-4">مرتب‌سازی</h3>
                <select
                  value={selectedSort}
                  onChange={(e) => setSelectedSort(e.target.value)}
                  className="w-full p-3 border border-ink/20 rounded bg-white"
                >
                  {SORT_OPTIONS.map((opt) => (
                    <option key={opt.value} value={opt.value}>
                      {opt.label}
                    </option>
                  ))}
                </select>
              </div>
            </div>
          </div>

          {/* محصولات */}
          <div className="md:col-span-3">
            <div className="text-sm text-ink/60 mb-6">
              {filtered.length} محصول یافت شد
            </div>
            <div className="grid grid-cols-2 gap-6 sm:grid-cols-3">
              {filtered.map((product) => (
                <div key={product.id}>
                  <ProductCard product={product} />
                </div>
              ))}
            </div>
            {filtered.length === 0 && (
              <div className="text-center py-20">
                <p className="text-ink/60">محصولی یافت نشد</p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
