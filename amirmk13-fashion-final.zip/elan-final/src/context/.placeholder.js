// Global state providers (CartContext, WishlistContext, etc.) are added when Smart Shopping features are built.
