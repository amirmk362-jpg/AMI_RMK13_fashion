import { createContext, useState } from 'react';

export const LanguageContext = createContext();

const translations = {
  fa: {
    home: 'خانه',
    shop: 'فروشگاه',
    cart: 'سبد خرید',
    login: 'ورود',
    addToCart: 'افزودن به سبد',
    price: 'قیمت',
    quantity: 'تعداد'
  },
  en: {
    home: 'Home',
    shop: 'Shop',
    cart: 'Cart',
    login: 'Login',
    addToCart: 'Add to Cart',
    price: 'Price',
    quantity: 'Quantity'
  }
};

export function LanguageProvider({ children }) {
  const [language, setLanguage] = useState('fa');

  const t = (key) => translations[language]?.[key] || key;

  return (
    <LanguageContext.Provider value={{ language, setLanguage, t }}>
      {children}
    </LanguageContext.Provider>
  );
}
