import { createContext, useState } from 'react';

export const CouponContext = createContext();

export function CouponProvider({ children }) {
  const [coupons] = useState([
    { code: 'SAVE10', discount: 10, name: 'تخفیف ۱۰%' },
    { code: 'FASHION20', discount: 20, name: 'تخفیف ۲۰%' },
    { code: 'WELCOME15', discount: 15, name: 'خوش‌آمدی ۱۵%' },
  ]);
  
  const [appliedCoupon, setAppliedCoupon] = useState(null);

  const applyCoupon = (code) => {
    const coupon = coupons.find(c => c.code === code.toUpperCase());
    if (coupon) {
      setAppliedCoupon(coupon);
      return { success: true, message: `کد ${coupon.name} اعمال شد` };
    }
    return { success: false, message: 'کد نامعتبر است' };
  };

  const removeCoupon = () => setAppliedCoupon(null);

  return (
    <CouponContext.Provider value={{ coupons, appliedCoupon, applyCoupon, removeCoupon }}>
      {children}
    </CouponContext.Provider>
  );
}
