export function generateInvoice(order) {
  return {
    invoiceNumber: '#' + Math.random().toString(36).substr(2, 9).toUpperCase(),
    date: new Date().toLocaleDateString('fa-IR'),
    items: order.cart,
    subtotal: order.subtotal,
    tax: order.subtotal * 0.09,
    total: order.subtotal * 1.09,
    customer: order.customer,
    shippingAddress: order.address
  };
}

export function printInvoice(invoice) {
  const content = `
    فاکتور خریداری
    ${invoice.invoiceNumber}
    تاریخ: ${invoice.date}
    
    مشتری: ${invoice.customer.name}
    ایمیل: ${invoice.customer.email}
    
    آدرس ارسال:
    ${invoice.shippingAddress}
    
    ${invoice.items.map(item => `${item.name} × ${item.quantity}: ${(item.price * item.quantity).toLocaleString('fa-IR')}`).join('\n')}
    
    مجموع: ${invoice.subtotal.toLocaleString('fa-IR')} تومان
    مالیات: ${invoice.tax.toLocaleString('fa-IR')} تومان
    کل: ${invoice.total.toLocaleString('fa-IR')} تومان
  `;

  const printWindow = window.open('', '', 'width=800,height=600');
  printWindow.document.write('<pre>' + content + '</pre>');
  printWindow.document.close();
  printWindow.print();
}
