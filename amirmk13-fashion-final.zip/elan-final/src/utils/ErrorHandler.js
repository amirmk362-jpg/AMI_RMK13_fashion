export const ErrorHandler = {
  handle: (error, context = '') => {
    console.error(`[Error in ${context}]`, error);
    return {
      success: false,
      message: error.message || 'خطای نامشخص',
      context
    };
  },

  catchAsync: (fn) => async (...args) => {
    try {
      return await fn(...args);
    } catch (error) {
      return ErrorHandler.handle(error, fn.name);
    }
  },

  notifyUser: (message, type = 'error') => {
    console.log(`[${type.toUpperCase()}] ${message}`);
    // In real app: send notification to user
  }
};
