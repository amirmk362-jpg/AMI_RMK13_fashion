// Mock Database (localStorage)
export const DatabaseMock = {
  users: new Map(),
  orders: new Map(),
  reviews: new Map(),

  createUser: (userData) => {
    const id = 'user-' + Date.now();
    const user = { id, ...userData, createdAt: new Date() };
    this.users.set(id, user);
    localStorage.setItem(`user-${id}`, JSON.stringify(user));
    return user;
  },

  getUser: (userId) => {
    return this.users.get(userId) || JSON.parse(localStorage.getItem(`user-${userId}`));
  },

  createOrder: (orderData) => {
    const id = 'order-' + Date.now();
    const order = { id, ...orderData, createdAt: new Date(), status: 'PENDING' };
    this.orders.set(id, order);
    localStorage.setItem(`order-${id}`, JSON.stringify(order));
    return order;
  },

  getOrders: (userId) => {
    const orders = [];
    this.orders.forEach(order => {
      if (order.userId === userId) orders.push(order);
    });
    return orders;
  },

  addReview: (productId, reviewData) => {
    const id = 'review-' + Date.now();
    const review = { id, productId, ...reviewData };
    this.reviews.set(id, review);
    localStorage.setItem(`review-${id}`, JSON.stringify(review));
    return review;
  }
};
