/**
 * Joins truthy class names together. Usage: cn("a", condition && "b", "c")
 */
export function cn(...classes) {
  return classes.filter(Boolean).join(" ");
}
