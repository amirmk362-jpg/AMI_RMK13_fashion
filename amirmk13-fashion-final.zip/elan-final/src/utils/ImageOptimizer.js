export function getOptimizedImageUrl(url, width = 800, quality = 80) {
  if (!url) return 'https://via.placeholder.com/800x800?text=Product';
  
  // If it's from picsum, add size params
  if (url.includes('picsum.photos')) {
    return `${url}?w=${width}&q=${quality}`;
  }
  
  return url;
}

export function getImageSrcSet(url) {
  return `
    ${getOptimizedImageUrl(url, 400)} 400w,
    ${getOptimizedImageUrl(url, 800)} 800w,
    ${getOptimizedImageUrl(url, 1200)} 1200w
  `;
}

export function lazyLoadImage(imgElement) {
  if ('IntersectionObserver' in window) {
    const observer = new IntersectionObserver((entries) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          const img = entry.target;
          img.src = img.dataset.src;
          img.classList.add('loaded');
          observer.unobserve(img);
        }
      });
    });
    observer.observe(imgElement);
  } else {
    imgElement.src = imgElement.dataset.src;
  }
}
