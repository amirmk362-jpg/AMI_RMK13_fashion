import { PRODUCTS } from '@/data/products';

export function getRelatedProducts(product, limit = 4) {
  return PRODUCTS.filter(
    p => p.id !== product.id && 
    (p.category === product.category || p.brand === product.brand)
  ).slice(0, limit);
}
