import { gsap } from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";

let isRegistered = false;

/**
 * Registers GSAP plugins exactly once for the whole app.
 * Re-registering on every component mount is a common source of
 * duplicated ScrollTrigger instances and dropped frame rate — calling
 * this guarded function from each component that needs GSAP is safe.
 */
export function registerGsap() {
  if (isRegistered || typeof window === "undefined") return;

  gsap.registerPlugin(ScrollTrigger);

  // Quiet console noise when a ref hasn't mounted yet (common during
  // fast route transitions) and set shared, GPU-friendly defaults.
  gsap.config({ nullTargetWarn: false });
  gsap.defaults({ ease: "power3.out", duration: 0.9, overwrite: "auto" });

  isRegistered = true;
}

/** Respect the user's OS-level motion preference. */
export const prefersReducedMotion = () =>
  typeof window !== "undefined" &&
  window.matchMedia("(prefers-reduced-motion: reduce)").matches;

/** Pause/resume heavy ambient animations when the tab isn't visible. */
export function onVisibilityChange(callback) {
  if (typeof document === "undefined") return () => {};
  const handler = () => callback(document.visibilityState === "visible");
  document.addEventListener("visibilitychange", handler);
  return () => document.removeEventListener("visibilitychange", handler);
}

export { gsap, ScrollTrigger };
