import { useEffect, useRef, useState } from "react";
import { useGSAP } from "@gsap/react";
import { gsap, registerGsap, prefersReducedMotion } from "@/animations/gsapConfig";
import { CheckBadgeIcon, CloseIcon } from "@/components/ui/icons";
import { RECENT_PURCHASES } from "@/data/recentPurchases";

registerGsap();

const SHOW_MS = 5000;
const GAP_MS = 4000;
const INITIAL_DELAY_MS = 2500;

export default function RecentPurchaseToast() {
  const [index, setIndex] = useState(0);
  const [visible, setVisible] = useState(false);
  const [dismissed, setDismissed] = useState(false);
  const toastRef = useRef(null);

  // Plain timers drive the show/hide cycle — this is a content swap on a
  // schedule, not a continuous animation, so setTimeout is the right tool
  // and GSAP only handles the actual transition below.
  useEffect(() => {
    if (dismissed) return;
    let showTimer;
    let hideTimer;

    const cycle = () => {
      setVisible(true);
      hideTimer = setTimeout(() => {
        setVisible(false);
        showTimer = setTimeout(() => {
          setIndex((i) => (i + 1) % RECENT_PURCHASES.length);
          cycle();
        }, GAP_MS);
      }, SHOW_MS);
    };

    const initialDelay = setTimeout(cycle, INITIAL_DELAY_MS);

    return () => {
      clearTimeout(initialDelay);
      clearTimeout(showTimer);
      clearTimeout(hideTimer);
    };
  }, [dismissed]);

  useGSAP(
    () => {
      if (!toastRef.current) return;

      if (prefersReducedMotion()) {
        gsap.set(toastRef.current, { opacity: visible ? 1 : 0 });
        return;
      }

      gsap.to(toastRef.current, {
        x: visible ? 0 : -16,
        opacity: visible ? 1 : 0,
        duration: 0.5,
        ease: visible ? "back.out(1.4)" : "power2.in",
      });
    },
    { dependencies: [visible], scope: toastRef }
  );

  if (dismissed) return null;
  const purchase = RECENT_PURCHASES[index];

  return (
    <div
      ref={toastRef}
      style={{ opacity: 0 }}
      role="status"
      className="pointer-events-auto fixed bottom-5 left-5 z-40 flex max-w-xs items-start gap-3 bg-chalk p-4 shadow-[0_8px_24px_rgba(23,24,28,0.15)]"
    >
      <CheckBadgeIcon width={20} height={20} className="mt-0.5 shrink-0 text-bottega" />

      <div className="min-w-0">
        <p className="text-sm text-ink">
          <span className="font-medium">{purchase.name}</span> just purchased
        </p>
        <p className="truncate text-sm text-ink/70">{purchase.product}</p>
        <p className="mt-0.5 font-mono text-[10px] uppercase tracking-widest text-ink/40">
          {purchase.timeAgo}
        </p>
      </div>

      <button
        onClick={() => setDismissed(true)}
        aria-label="Dismiss notification"
        className="ml-auto shrink-0 text-ink/40 hover:text-ink"
      >
        <CloseIcon width={14} height={14} />
      </button>
    </div>
  );
}
