import { useState } from "react";
import { HeartIcon, StarIcon } from "@/components/ui/icons";

const BADGE_STYLES = {
  Sale: "bg-rosewood text-chalk",
  New: "bg-bottega text-chalk",
  "Flash Sale": "bg-rosewood text-chalk",
};

/**
 * `badge` lets a parent section force a label ("New", "Sale", "Flash Sale",
 * ...). If omitted, the card falls back to auto-detecting a sale from the
 * price fields so existing call sites don't need to change.
 */
export default function ProductCard({ product, badge }) {
  const [wishlisted, setWishlisted] = useState(false);
  const { brand, name, image, price, discountPrice, rating, reviews, colors } = product;
  const onSale = Boolean(discountPrice) && discountPrice < price;
  const resolvedBadge = badge || (onSale ? "Sale" : null);

  return (
    <article className="group">
      <div className="relative aspect-[4/5] overflow-hidden bg-mist">
        <img
          src={image}
          alt={`${brand} — ${name}`}
          width={600}
          height={750}
          loading="lazy"
          decoding="async"
          className="h-full w-full object-cover transition-transform duration-500 ease-editorial group-hover:scale-105"
        />

        {resolvedBadge && (
          <span
            className={`absolute left-3 top-3 px-2 py-1 font-mono text-[10px] uppercase tracking-widest ${
              BADGE_STYLES[resolvedBadge] ?? "bg-ink text-chalk"
            }`}
          >
            {resolvedBadge}
          </span>
        )}

        <button
          onClick={() => setWishlisted((w) => !w)}
          aria-label={wishlisted ? "Remove from wishlist" : "Add to wishlist"}
          aria-pressed={wishlisted}
          className="absolute right-3 top-3 rounded-full bg-chalk/90 p-2 text-ink transition-transform hover:scale-110"
        >
          <HeartIcon
            width={16}
            height={16}
            fill={wishlisted ? "currentColor" : "none"}
            className={wishlisted ? "text-rosewood" : "text-ink"}
          />
        </button>
      </div>

      <div className="mt-3">
        <p className="font-mono text-[11px] uppercase tracking-widest text-ink/50">{brand}</p>
        <h3 className="mt-1 text-sm text-ink">{name}</h3>

        <div className="mt-1 flex items-center gap-1 text-xs text-ink/60">
          <StarIcon width={13} height={13} fill="currentColor" className="text-brass" />
          <span>{rating}</span>
          <span className="text-ink/40">({reviews})</span>
        </div>

        <div className="mt-2 flex items-center gap-2">
          {onSale ? (
            <>
              <span className="text-sm font-medium text-rosewood">${discountPrice}</span>
              <span className="text-xs text-ink/40 line-through">${price}</span>
            </>
          ) : (
            <span className="text-sm font-medium text-ink">${price}</span>
          )}
        </div>

        {colors?.length > 0 && (
          <div className="mt-2 flex gap-1.5">
            {colors.map((color) => (
              <span
                key={color}
                style={{ backgroundColor: color }}
                className="h-3 w-3 rounded-full border border-ink/10"
              />
            ))}
          </div>
        )}
      </div>
    </article>
  );
}
