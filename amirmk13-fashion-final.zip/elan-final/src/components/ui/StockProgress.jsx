export default function StockProgress({ sold, total }) {
  const percent = total > 0 ? Math.min(100, Math.round((sold / total) * 100)) : 0;
  const remaining = Math.max(0, total - sold);

  return (
    <div className="mt-2">
      <div className="h-1 w-full overflow-hidden rounded-full bg-mist">
        <div
          className="h-full rounded-full bg-rosewood transition-[width] duration-500"
          style={{ width: `${percent}%` }}
        />
      </div>
      <p className="mt-1 font-mono text-[10px] uppercase tracking-widest text-ink/50">
        {remaining <= 5 ? `Only ${remaining} left` : `${percent}% claimed`}
      </p>
    </div>
  );
}
