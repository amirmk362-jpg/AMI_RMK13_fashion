import { cn } from "@/utils/cn";

const VARIANTS = {
  primary: "bg-ink text-chalk hover:bg-bottega",
  outline: "border border-ink/80 text-ink hover:border-ink hover:bg-ink hover:text-chalk",
  ghost: "text-chalk underline-offset-4 hover:underline",
};

/**
 * Polymorphic button — pass `as="a"` with `href` to render a link that
 * still carries the same visual treatment.
 */
export default function Button({
  as: Component = "button",
  variant = "primary",
  className,
  children,
  ...props
}) {
  return (
    <Component
      className={cn(
        "inline-flex items-center justify-center gap-2 px-7 py-3 text-sm font-medium uppercase tracking-widest transition-colors duration-300 ease-editorial focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-bottega",
        VARIANTS[variant],
        className
      )}
      {...props}
    >
      {children}
    </Component>
  );
}
