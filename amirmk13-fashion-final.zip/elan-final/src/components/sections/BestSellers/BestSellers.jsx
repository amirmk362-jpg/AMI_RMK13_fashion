import { useScrollReveal } from "@/hooks/useScrollReveal";
import { BEST_SELLERS } from "@/data/bestSellers";
import ProductCard from "@/components/ui/ProductCard";

export default function BestSellers() {
  const revealScope = useScrollReveal({ stagger: 0.08 });

  return (
    <section ref={revealScope} className="bg-chalk py-20 sm:py-28">
      <div className="container">
        <div data-reveal className="flex flex-wrap items-end justify-between gap-4">
          <div>
            <span className="font-mono text-xs uppercase tracking-widest text-ink/50">
              Best Sellers
            </span>
            <h2 className="mt-2 font-display text-3xl sm:text-4xl">
              What everyone's wearing.
            </h2>
          </div>
          <a
            href="/shop/best-sellers"
            className="text-xs font-medium uppercase tracking-widest text-ink underline-offset-4 hover:underline"
          >
            View All
          </a>
        </div>

        <div className="mt-10 grid grid-cols-2 gap-5 sm:grid-cols-3 lg:grid-cols-4">
          {BEST_SELLERS.map((product) => (
            <div key={product.id} data-reveal>
              <ProductCard product={product} />
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
