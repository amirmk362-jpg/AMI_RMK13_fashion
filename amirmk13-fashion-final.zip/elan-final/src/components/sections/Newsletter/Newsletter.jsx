import { useRef, useState } from "react";
import { useGSAP } from "@gsap/react";
import { gsap, registerGsap, prefersReducedMotion } from "@/animations/gsapConfig";
import { useScrollReveal } from "@/hooks/useScrollReveal";
import { CheckBadgeIcon } from "@/components/ui/icons";
import Button from "@/components/ui/Button";

registerGsap();

const EMAIL_PATTERN = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

export default function Newsletter() {
  const revealScope = useScrollReveal();
  const [email, setEmail] = useState("");
  const [status, setStatus] = useState("idle"); // idle | error | success
  const successRef = useRef(null);

  // Small one-off celebratory pop on success — transform/opacity only,
  // fires once per submission rather than on every render.
  useGSAP(
    () => {
      if (status !== "success" || !successRef.current || prefersReducedMotion()) return;
      gsap.fromTo(
        successRef.current,
        { opacity: 0, scale: 0.85 },
        { opacity: 1, scale: 1, duration: 0.5, ease: "back.out(1.7)" }
      );
    },
    { dependencies: [status], scope: successRef }
  );

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!EMAIL_PATTERN.test(email)) {
      setStatus("error");
      return;
    }
    // No backend wired up yet — a real subscribe API call (Klaviyo,
    // Mailchimp, etc.) is added in a later integration step.
    setStatus("success");
  };

  return (
    <section ref={revealScope} className="bg-ink py-20 text-chalk sm:py-28">
      <div className="container max-w-xl text-center">
        <div data-reveal>
          <span className="font-mono text-xs uppercase tracking-widest text-chalk/60">
            Newsletter
          </span>
          <h2 className="mt-3 font-display text-3xl sm:text-4xl">
            Get 10% off your first order.
          </h2>
          <p className="mt-3 text-sm text-chalk/70">
            New arrivals, restocks, and the occasional surprise discount —
            once or twice a month, never more.
          </p>
        </div>

        <div data-reveal className="mt-8">
          {status === "success" ? (
            <p
              ref={successRef}
              className="flex items-center justify-center gap-2 text-sm font-medium text-chalk"
            >
              <CheckBadgeIcon width={18} height={18} className="text-bottega" />
              You're on the list — check your inbox for your code.
            </p>
          ) : (
            <form onSubmit={handleSubmit} className="flex flex-col gap-3 sm:flex-row">
              <label htmlFor="newsletter-email" className="sr-only">
                Email address
              </label>
              <input
                id="newsletter-email"
                type="email"
                required
                value={email}
                onChange={(e) => {
                  setEmail(e.target.value);
                  if (status === "error") setStatus("idle");
                }}
                placeholder="you@example.com"
                className="w-full flex-1 border border-chalk/30 bg-transparent px-4 py-3 text-sm text-chalk placeholder:text-chalk/40 focus:border-chalk focus:outline-none"
              />
              <Button
                type="submit"
                variant="primary"
                className="bg-chalk text-ink hover:bg-bottega hover:text-chalk"
              >
                Subscribe
              </Button>
            </form>
          )}

          {status === "error" && (
            <p className="mt-3 inline-block bg-rosewood/20 px-3 py-1.5 text-xs text-chalk">
              Please enter a valid email address.
            </p>
          )}

          <p className="mt-4 text-xs text-chalk/50">
            By subscribing you agree to our Privacy Policy. Unsubscribe anytime.
          </p>
        </div>
      </div>
    </section>
  );
}
