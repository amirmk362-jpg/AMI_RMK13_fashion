export { default } from "./Newsletter";
