import { HeartIcon, InstagramIcon } from "@/components/ui/icons";
import { useScrollReveal } from "@/hooks/useScrollReveal";
import { INSTAGRAM_POSTS } from "@/data/instagram";

export default function InstagramGallery() {
  const revealScope = useScrollReveal({ stagger: 0.06 });

  return (
    <section ref={revealScope} className="bg-chalk py-20 sm:py-28">
      <div className="container">
        <div data-reveal className="flex flex-wrap items-end justify-between gap-4">
          <div>
            <span className="font-mono text-xs uppercase tracking-widest text-ink/50">
              Community
            </span>
            <h2 className="mt-2 font-display text-3xl sm:text-4xl">
              Tag #WearELAN to be featured.
            </h2>
          </div>
          <a
            href="https://instagram.com"
            target="_blank"
            rel="noreferrer"
            className="flex items-center gap-2 text-xs font-medium uppercase tracking-widest text-ink underline-offset-4 hover:underline"
          >
            <InstagramIcon width={16} height={16} />
            @elan_official
          </a>
        </div>

        <div className="mt-10 grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-6">
          {INSTAGRAM_POSTS.map((post) => (
            <a
              key={post.id}
              href={post.url}
              target="_blank"
              rel="noreferrer"
              data-reveal
              className="group relative block aspect-square overflow-hidden bg-mist"
            >
              <img
                src={post.image}
                alt="Customer styling an ÉLAN piece, shared on Instagram"
                width={500}
                height={500}
                loading="lazy"
                decoding="async"
                className="h-full w-full object-cover transition-transform duration-500 ease-out group-hover:scale-105"
              />
              <div className="absolute inset-0 flex items-center justify-center gap-1.5 bg-ink/0 text-chalk opacity-0 transition-all duration-300 group-hover:bg-ink/50 group-hover:opacity-100">
                <HeartIcon width={16} height={16} fill="currentColor" />
                <span className="text-sm font-medium">{post.likes}</span>
              </div>
            </a>
          ))}
        </div>
      </div>
    </section>
  );
}
