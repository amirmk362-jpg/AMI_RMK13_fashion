export { default } from "./InstagramGallery";
