export { default } from "./FlashSale";
