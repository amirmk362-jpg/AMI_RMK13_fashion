import { useState } from "react";
import ProductCard from "@/components/ui/ProductCard";
import StockProgress from "@/components/ui/StockProgress";
import { useCountdown } from "@/hooks/useCountdown";
import { useScrollReveal } from "@/hooks/useScrollReveal";
import { FLASH_SALE } from "@/data/flashSale";

function CountdownUnit({ value, label }) {
  return (
    <div className="flex flex-col items-center">
      <span className="flex h-14 w-14 items-center justify-center rounded-sm bg-chalk font-display text-2xl text-rosewood sm:h-16 sm:w-16 sm:text-3xl">
        {String(value).padStart(2, "0")}
      </span>
      <span className="mt-2 font-mono text-[10px] uppercase tracking-widest text-chalk/70">
        {label}
      </span>
    </div>
  );
}

export default function FlashSale() {
  const revealScope = useScrollReveal({ stagger: 0.08 });
  // Created once on mount so the countdown hook isn't handed a new Date
  // (and a fresh interval) on every render.
  const [endTime] = useState(() => new Date(Date.now() + 48 * 60 * 60 * 1000));
  const { days, hours, minutes, seconds, expired } = useCountdown(endTime);

  return (
    <section ref={revealScope} className="bg-rosewood py-20 text-chalk sm:py-28">
      <div className="container">
        <div data-reveal className="flex flex-wrap items-center justify-between gap-8">
          <div>
            <span className="font-mono text-xs uppercase tracking-widest text-chalk/70">
              Flash Sale
            </span>
            <h2 className="mt-2 font-display text-3xl sm:text-4xl">
              {expired ? "This drop just ended." : "Up to 40% off — 48 hours only."}
            </h2>
          </div>

          {!expired && (
            <div className="flex gap-3 sm:gap-4">
              <CountdownUnit value={days} label="Days" />
              <CountdownUnit value={hours} label="Hrs" />
              <CountdownUnit value={minutes} label="Min" />
              <CountdownUnit value={seconds} label="Sec" />
            </div>
          )}
        </div>

        <div className="mt-10 grid grid-cols-2 gap-x-5 gap-y-8 sm:grid-cols-3 lg:grid-cols-4">
          {FLASH_SALE.map((product) => (
            <div key={product.id} data-reveal className="bg-chalk p-3">
              <ProductCard product={product} badge="Flash Sale" />
              <StockProgress sold={product.stockSold} total={product.stockTotal} />
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
