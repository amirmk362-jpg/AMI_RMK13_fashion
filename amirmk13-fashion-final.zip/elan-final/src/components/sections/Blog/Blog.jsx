import { useScrollReveal } from "@/hooks/useScrollReveal";
import { BLOG_POSTS } from "@/data/blog";

export default function Blog() {
  const revealScope = useScrollReveal({ stagger: 0.1 });

  return (
    <section ref={revealScope} className="bg-chalk py-20 sm:py-28">
      <div className="container">
        <div data-reveal className="flex flex-wrap items-end justify-between gap-4">
          <div>
            <span className="font-mono text-xs uppercase tracking-widest text-ink/50">
              Journal
            </span>
            <h2 className="mt-2 font-display text-3xl sm:text-4xl">
              Stories from the studio.
            </h2>
          </div>
          <a
            href="/journal"
            className="text-xs font-medium uppercase tracking-widest text-ink underline-offset-4 hover:underline"
          >
            View All Articles
          </a>
        </div>

        <div className="mt-10 grid gap-10 sm:grid-cols-3 sm:gap-8">
          {BLOG_POSTS.map((post) => (
            <a key={post.id} href={post.href} data-reveal className="group block">
              <div className="aspect-[4/3] overflow-hidden bg-mist">
                <img
                  src={post.image}
                  alt={post.title}
                  width={700}
                  height={520}
                  loading="lazy"
                  decoding="async"
                  className="h-full w-full object-cover transition-transform duration-500 ease-out group-hover:scale-105"
                />
              </div>

              <p className="mt-4 font-mono text-[11px] uppercase tracking-widest text-bottega">
                {post.category}
              </p>
              <h3 className="mt-2 font-display text-xl leading-snug">{post.title}</h3>
              <p className="mt-2 line-clamp-2 text-sm text-ink/65">{post.excerpt}</p>

              <p className="mt-3 font-mono text-[11px] uppercase tracking-widest text-ink/40">
                {post.date} · {post.readTime}
              </p>
            </a>
          ))}
        </div>
      </div>
    </section>
  );
}
