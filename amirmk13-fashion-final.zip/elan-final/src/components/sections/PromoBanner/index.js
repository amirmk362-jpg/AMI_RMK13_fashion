export { default } from "./PromoBanner";
