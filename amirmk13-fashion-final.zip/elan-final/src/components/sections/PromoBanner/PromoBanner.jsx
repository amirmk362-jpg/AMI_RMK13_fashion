import { useRef, useState } from "react";
import { useScrollReveal } from "@/hooks/useScrollReveal";
import { useParallax } from "@/hooks/useParallax";
import Button from "@/components/ui/Button";

const PROMO_IMAGE = "https://picsum.photos/seed/elan-promo/700/600";

export default function PromoBanner() {
  const revealScope = useScrollReveal({ stagger: 0.12 });
  const imageRef = useParallax({ amount: 8 });
  const [copied, setCopied] = useState(false);

  const handleCopyCode = async () => {
    try {
      await navigator.clipboard.writeText("CAPSULE10");
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch (error) {
      console.error("Failed to copy:", error);
    }
  };

  return (
    <section ref={revealScope} className="bg-chalk py-20 sm:py-28">
      <div className="container grid items-center gap-12 lg:grid-cols-2">
        <div data-reveal>
          <span className="font-mono text-xs uppercase tracking-widest text-ink/50">
            Special Offer
          </span>

          <h2 className="mt-4 font-display text-3xl leading-snug sm:text-4xl">
            Build a capsule, save 10%.
          </h2>

          <p className="mt-4 max-w-md text-sm leading-relaxed text-ink/70">
            Our most-shopped collection of essentials — jeans, tees, jackets,
            and sweaters — now available at a single price point.
          </p>

          <div className="mt-6 flex flex-col gap-3 sm:flex-row sm:items-center">
            <button
              onClick={handleCopyCode}
              className="inline-flex items-center gap-2 border border-ink px-4 py-3 font-mono text-sm uppercase tracking-widest text-ink transition-colors hover:bg-ink hover:text-chalk"
            >
              {copied ? "Copied!" : "CAPSULE10"}
            </button>
            <Button variant="outline">Shop Collection</Button>
          </div>
        </div>

        <div data-reveal className="relative aspect-[4/3] overflow-hidden bg-mist">
          <img
            ref={imageRef}
            src={PROMO_IMAGE}
            alt="Capsule collection styling inspiration"
            width={700}
            height={600}
            loading="lazy"
            decoding="async"
            className="absolute -top-[10%] h-[120%] w-full object-cover"
          />
        </div>
      </div>
    </section>
  );
}
