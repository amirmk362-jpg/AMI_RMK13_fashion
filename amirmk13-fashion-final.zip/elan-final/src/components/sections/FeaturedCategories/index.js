export { default } from "./FeaturedCategories";
