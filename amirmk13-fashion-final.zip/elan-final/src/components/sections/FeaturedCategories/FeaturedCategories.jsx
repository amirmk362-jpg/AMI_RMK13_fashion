import { useScrollReveal } from "@/hooks/useScrollReveal";
import { CATEGORIES } from "@/data/categories";

export default function FeaturedCategories() {
  const revealScope = useScrollReveal({ stagger: 0.05 });

  return (
    <section ref={revealScope} className="bg-chalk py-20 sm:py-28">
      <div className="container">
        <div data-reveal className="max-w-xl">
          <span className="font-mono text-xs uppercase tracking-widest text-ink/50">
            Shop by Category
          </span>
          <h2 className="mt-2 font-display text-3xl sm:text-4xl">
            Find your next favorite.
          </h2>
        </div>

        <div className="mt-10 grid grid-cols-3 gap-x-4 gap-y-8 sm:grid-cols-5">
          {CATEGORIES.map((category) => (
            <a
              key={category.id}
              href={category.href}
              data-reveal
              className="group flex flex-col items-center text-center"
            >
              <div className="h-20 w-20 overflow-hidden rounded-full bg-mist sm:h-24 sm:w-24">
                <img
                  src={category.image}
                  alt={category.name}
                  width={240}
                  height={240}
                  loading="lazy"
                  decoding="async"
                  className="h-full w-full object-cover transition-transform duration-500 ease-out group-hover:scale-110"
                />
              </div>
              <span className="mt-3 text-xs font-medium uppercase tracking-widest text-ink transition-colors group-hover:text-bottega">
                {category.name}
              </span>
            </a>
          ))}
        </div>
      </div>
    </section>
  );
}
