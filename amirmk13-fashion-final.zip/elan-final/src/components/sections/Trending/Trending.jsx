import { ChevronRightIcon, TrendUpIcon } from "@/components/ui/icons";
import { useScrollReveal } from "@/hooks/useScrollReveal";
import { TRENDING } from "@/data/trending";

export default function Trending() {
  const revealScope = useScrollReveal({ stagger: 0.06 });

  return (
    <section ref={revealScope} className="bg-chalk py-20 sm:py-28">
      <div className="container">
        <div data-reveal className="flex flex-wrap items-end justify-between gap-4">
          <div>
            <span className="font-mono text-xs uppercase tracking-widest text-ink/50">
              Trending Now
            </span>
            <h2 className="mt-2 font-display text-3xl sm:text-4xl">
              What everyone's adding to cart.
            </h2>
          </div>

          <span className="flex items-center gap-2 font-mono text-xs uppercase tracking-widest text-ink/50">
            <span className="h-1.5 w-1.5 animate-pulse rounded-full bg-bottega" />
            Updated hourly
          </span>
        </div>

        <div className="mt-8 border-t border-ink/10">
          {TRENDING.map((product, index) => (
            <a
              key={product.id}
              href={`/products/${product.id}`}
              data-reveal
              className="group flex items-center gap-4 border-b border-ink/10 py-5 transition-colors hover:bg-mist/40 sm:gap-6"
            >
              <span className="w-8 shrink-0 font-display text-2xl text-ink/20 sm:w-12 sm:text-4xl">
                {String(index + 1).padStart(2, "0")}
              </span>

              <div className="h-16 w-14 shrink-0 overflow-hidden bg-mist sm:h-20 sm:w-16">
                <img
                  src={product.image}
                  alt={`${product.brand} — ${product.name}`}
                  width={300}
                  height={300}
                  loading="lazy"
                  decoding="async"
                  className="h-full w-full object-cover transition-transform duration-500 ease-editorial group-hover:scale-105"
                />
              </div>

              <div className="min-w-0 flex-1">
                <p className="font-mono text-[11px] uppercase tracking-widest text-ink/50">
                  {product.brand}
                </p>
                <h3 className="mt-0.5 truncate text-sm text-ink sm:text-base">
                  {product.name}
                </h3>
              </div>

              <div className="hidden text-right sm:block">
                <p className="text-sm font-medium text-ink">${product.price}</p>
                <p className="mt-0.5 flex items-center justify-end gap-1 text-xs text-bottega">
                  <TrendUpIcon width={12} height={12} />
                  {product.trendPercent}% this week
                </p>
              </div>

              <ChevronRightIcon
                width={16}
                height={16}
                className="hidden shrink-0 text-ink/30 transition-transform group-hover:translate-x-1 sm:block"
              />
            </a>
          ))}
        </div>
      </div>
    </section>
  );
}
