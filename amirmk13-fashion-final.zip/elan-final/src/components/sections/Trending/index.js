export { default } from "./Trending";
