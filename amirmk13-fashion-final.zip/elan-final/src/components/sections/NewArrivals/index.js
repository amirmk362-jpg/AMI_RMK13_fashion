export { default } from "./NewArrivals";
