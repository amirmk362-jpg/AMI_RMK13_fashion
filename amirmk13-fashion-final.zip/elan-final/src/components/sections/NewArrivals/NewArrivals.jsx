import { useRef } from "react";
import { useScrollReveal } from "@/hooks/useScrollReveal";
import { ChevronLeftIcon, ChevronRightIcon } from "@/components/ui/icons";
import { NEW_ARRIVALS } from "@/data/newArrivals";
import ProductCard from "@/components/ui/ProductCard";

export default function NewArrivals() {
  const revealScope = useScrollReveal({ stagger: 0.08 });
  const scrollContainerRef = useRef(null);

  const scroll = (direction) => {
    if (scrollContainerRef.current) {
      const { scrollLeft, clientWidth } = scrollContainerRef.current;
      const scrollAmount = clientWidth * 0.25;
      scrollContainerRef.current.scrollBy({
        left: direction === "left" ? -scrollAmount : scrollAmount,
        behavior: "smooth",
      });
    }
  };

  return (
    <section ref={revealScope} className="bg-chalk py-20 sm:py-28">
      <div className="container">
        <div data-reveal className="flex flex-wrap items-end justify-between gap-4">
          <div>
            <span className="font-mono text-xs uppercase tracking-widest text-ink/50">
              New In
            </span>
            <h2 className="mt-2 font-display text-3xl sm:text-4xl">
              Fresh arrivals this week.
            </h2>
          </div>
          <div className="flex gap-2">
            <button
              onClick={() => scroll("left")}
              aria-label="Scroll left"
              className="flex h-10 w-10 items-center justify-center border border-ink/20 text-ink transition-colors hover:border-ink hover:bg-ink/5"
            >
              <ChevronLeftIcon width={16} height={16} />
            </button>
            <button
              onClick={() => scroll("right")}
              aria-label="Scroll right"
              className="flex h-10 w-10 items-center justify-center border border-ink/20 text-ink transition-colors hover:border-ink hover:bg-ink/5"
            >
              <ChevronRightIcon width={16} height={16} />
            </button>
          </div>
        </div>

        <div
          ref={scrollContainerRef}
          className="mt-10 flex snap-x snap-mandatory gap-4 overflow-x-auto scroll-smooth"
          style={{ scrollBehavior: "smooth" }}
        >
          {NEW_ARRIVALS.map((product) => (
            <div
              key={product.id}
              data-reveal
              className="w-[68%] shrink-0 snap-start sm:w-[38%] lg:w-[23%]"
            >
              <ProductCard product={product} badge="New" />
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
