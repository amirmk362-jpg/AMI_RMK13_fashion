import { useScrollReveal } from "@/hooks/useScrollReveal";
import { ShieldIcon, CheckBadgeIcon, RefreshIcon, TruckIcon } from "@/components/ui/icons";
import { TRUST_BADGES, TRUST_STATS } from "@/data/trust";

const ICONS = {
  shield: ShieldIcon,
  check: CheckBadgeIcon,
  refresh: RefreshIcon,
  truck: TruckIcon,
};

export default function TrustIndicators() {
  const revealScope = useScrollReveal({ stagger: 0.08 });

  return (
    <section ref={revealScope} className="bg-mist/40 py-16 sm:py-20">
      <div className="container">
        <div data-reveal className="grid grid-cols-2 gap-y-8 sm:grid-cols-4">
          {TRUST_BADGES.map((badge) => {
            const Icon = ICONS[badge.icon];
            return (
              <div
                key={badge.id}
                className="flex flex-col items-center gap-2 text-center sm:flex-row sm:text-left"
              >
                <Icon width={22} height={22} className="shrink-0 text-bottega" />
                <span className="text-xs font-medium uppercase tracking-widest text-ink/70 sm:text-[11px]">
                  {badge.label}
                </span>
              </div>
            );
          })}
        </div>

        <div
          data-reveal
          className="mt-14 grid grid-cols-2 gap-8 border-t border-ink/10 pt-10 sm:grid-cols-4"
        >
          {TRUST_STATS.map((stat) => (
            <div key={stat.label} className="text-center">
              <p className="font-display text-3xl sm:text-4xl">{stat.value}</p>
              <p className="mt-1 font-mono text-[10px] uppercase tracking-widest text-ink/50">
                {stat.label}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
