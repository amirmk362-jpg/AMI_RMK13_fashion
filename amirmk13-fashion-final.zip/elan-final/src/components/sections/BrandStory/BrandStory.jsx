import { useScrollReveal } from "@/hooks/useScrollReveal";
import { useParallax } from "@/hooks/useParallax";
import { STORY_STATS } from "@/data/brandStory";

const STORY_IMAGE = "https://picsum.photos/seed/elan-story/900/1100";

export default function BrandStory() {
  const revealScope = useScrollReveal({ stagger: 0.12 });
  const imageRef = useParallax({ amount: 8 });

  return (
    <section ref={revealScope} className="bg-chalk py-20 sm:py-28">
      <div className="container grid items-center gap-12 lg:grid-cols-2">
        <div data-reveal className="relative">
          <div className="relative aspect-[4/5] overflow-hidden">
            <img
              ref={imageRef}
              src={STORY_IMAGE}
              alt="ÉLAN atelier, where every garment is cut and finished"
              width={900}
              height={1100}
              loading="lazy"
              decoding="async"
              className="absolute -top-[10%] h-[120%] w-full object-cover"
            />
          </div>
          <div className="absolute -bottom-5 left-5 bg-chalk px-4 py-2 shadow-[0_1px_8px_rgba(23,24,28,0.08)]">
            <p className="font-mono text-[10px] uppercase tracking-widest text-ink/60">
              Atelier — Lisbon, Est. 2014
            </p>
          </div>
        </div>

        <div data-reveal>
          <span className="font-mono text-xs uppercase tracking-widest text-ink/50">
            Our Story
          </span>

          <p className="mt-4 font-display text-2xl leading-snug sm:text-3xl">
            "We started ÉLAN with one rule: nothing leaves the atelier unless
            we'd wear it ourselves."
          </p>

          <p className="mt-6 max-w-md text-sm leading-relaxed text-ink/70 sm:text-base">
            What began as a single tailoring workshop has grown into a
            full wardrobe — but the standard hasn't moved. Every piece is
            still developed in-house, tested on our own team first, and
            only released once it earns a permanent place in someone's
            rotation, not just their closet.
          </p>

          <div className="mt-8 grid grid-cols-3 gap-6 border-t border-ink/10 pt-6">
            {STORY_STATS.map((stat) => (
              <div key={stat.label}>
                <p className="font-display text-2xl sm:text-3xl">{stat.value}</p>
                <p className="mt-1 font-mono text-[10px] uppercase tracking-widest text-ink/50">
                  {stat.label}
                </p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
