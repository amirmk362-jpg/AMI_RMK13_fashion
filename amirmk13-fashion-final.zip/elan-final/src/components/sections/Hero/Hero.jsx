import { useRef } from "react";
import { useTextReveal } from "@/hooks/useTextReveal";
import { useMarquee } from "@/hooks/useMarquee";
import Button from "@/components/ui/Button";

const HERO_IMAGE = "https://picsum.photos/seed/elan-hero/1400/1800";
const CATEGORIES = ["New Arrivals", "Best Sellers", "On Sale", "Trending"];

export default function Hero() {
  const headlineRef = useRef(null);
  const marqueeRef = useMarquee();
  useTextReveal(headlineRef);

  return (
    <section className="relative min-h-screen w-full overflow-hidden bg-chalk">
      <div className="relative h-screen w-full">
        <img
          src={HERO_IMAGE}
          alt="ÉLAN — Tailored Essentials"
          width={1400}
          height={1800}
          priority
          fetchPriority="high"
          loading="eager"
          decoding="sync"
          className="absolute inset-0 h-full w-full object-cover"
        />

        <div className="absolute inset-0 bg-gradient-to-b from-ink/30 via-transparent to-ink/20" />

        <div className="absolute inset-0 flex flex-col items-center justify-center">
          <div className="max-w-2xl text-center">
            <h1
              ref={headlineRef}
              className="font-display text-5xl leading-tight text-chalk sm:text-6xl lg:text-7xl"
              style={{ overflow: "hidden", lineHeight: "1.1" }}
            >
              <span style={{ display: "block", overflow: "hidden" }}>
                Tailored
              </span>
              <span style={{ display: "block", overflow: "hidden" }}>
                Essentials
              </span>
            </h1>

            <p className="mt-6 text-base text-chalk/80 sm:text-lg">
              Quality pieces built to last, made in our Lisbon atelier.
            </p>

            <div className="mt-8 flex flex-col gap-3 sm:flex-row sm:justify-center">
              <Button variant="primary" className="bg-chalk text-ink hover:bg-bottega hover:text-chalk">
                Shop Now
              </Button>
              <Button variant="outline" className="border-chalk text-chalk hover:bg-chalk hover:text-ink">
                Our Story
              </Button>
            </div>
          </div>
        </div>
      </div>

      <div
        ref={marqueeRef}
        className="overflow-hidden bg-bottega py-3 text-chalk"
        style={{ position: "relative" }}
      >
        <div style={{ display: "flex", whiteSpace: "nowrap" }}>
          {[...CATEGORIES, ...CATEGORIES].map((cat, i) => (
            <span
              key={i}
              className="inline-block px-6 font-mono text-xs uppercase tracking-widest"
            >
              {cat}
            </span>
          ))}
        </div>
      </div>
    </section>
  );
}
