import { useScrollReveal } from "@/hooks/useScrollReveal";
import { FAQS } from "@/data/faq";
import AccordionItem from "./AccordionItem";

export default function FAQ() {
  const revealScope = useScrollReveal({ stagger: 0.1 });

  return (
    <section ref={revealScope} className="bg-chalk py-20 sm:py-28">
      <div className="container grid gap-10 lg:grid-cols-[280px_1fr] lg:gap-16">
        <div data-reveal>
          <span className="font-mono text-xs uppercase tracking-widest text-ink/50">
            FAQ
          </span>
          <h2 className="mt-2 font-display text-3xl sm:text-4xl">Good to know.</h2>
          <p className="mt-4 text-sm text-ink/60">
            Can't find what you're looking for?{" "}
            <a href="/contact" className="underline underline-offset-4 hover:text-ink">
              Reach our team directly
            </a>
            .
          </p>
        </div>

        <div data-reveal className="border-t border-ink/10">
          {FAQS.map((faq) => (
            <AccordionItem key={faq.id} question={faq.question} answer={faq.answer} />
          ))}
        </div>
      </div>
    </section>
  );
}
