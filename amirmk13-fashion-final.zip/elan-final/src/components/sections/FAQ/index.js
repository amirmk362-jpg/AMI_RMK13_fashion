export { default } from "./FAQ";
