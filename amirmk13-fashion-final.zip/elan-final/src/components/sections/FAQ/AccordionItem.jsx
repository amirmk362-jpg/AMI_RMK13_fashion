import { useRef, useState } from "react";
import { useGSAP } from "@gsap/react";
import { gsap, registerGsap, prefersReducedMotion } from "@/animations/gsapConfig";
import { ChevronRightIcon } from "@/components/ui/icons";

registerGsap();

/**
 * Height is the one layout property we deliberately animate with GSAP
 * here instead of transform/opacity — there's no way to know an answer's
 * expanded height in advance, and accordions only animate one element at
 * a time on a user click (not on scroll or in a loop), so the layout cost
 * is a single short-lived reflow rather than a per-frame one.
 */
export default function AccordionItem({ question, answer }) {
  const [open, setOpen] = useState(false);
  const panelRef = useRef(null);
  const contentRef = useRef(null);

  useGSAP(
    () => {
      if (!panelRef.current || !contentRef.current) return;
      const targetHeight = open ? contentRef.current.scrollHeight : 0;

      if (prefersReducedMotion()) {
        gsap.set(panelRef.current, { height: targetHeight });
        return;
      }

      gsap.to(panelRef.current, {
        height: targetHeight,
        duration: 0.4,
        ease: "power2.inOut",
      });
    },
    { dependencies: [open], scope: panelRef }
  );

  return (
    <div className="border-b border-ink/10">
      <button
        onClick={() => setOpen((o) => !o)}
        aria-expanded={open}
        className="flex w-full items-center justify-between gap-4 py-5 text-left"
      >
        <span className="text-sm font-medium text-ink sm:text-base">{question}</span>
        <ChevronRightIcon
          width={16}
          height={16}
          className={`shrink-0 text-ink/50 transition-transform duration-300 ${
            open ? "rotate-90" : ""
          }`}
        />
      </button>

      <div ref={panelRef} className="overflow-hidden" style={{ height: 0 }}>
        <p ref={contentRef} className="pb-5 pr-8 text-sm leading-relaxed text-ink/70">
          {answer}
        </p>
      </div>
    </div>
  );
}
