export { default } from "./FeaturedCollections";
