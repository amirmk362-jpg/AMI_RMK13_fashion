import { useScrollReveal } from "@/hooks/useScrollReveal";
import { cn } from "@/utils/cn";
import { COLLECTIONS } from "@/data/collections";

export default function FeaturedCollections() {
  const revealScope = useScrollReveal({ stagger: 0.12 });

  return (
    <section ref={revealScope} className="bg-ink py-20 text-chalk sm:py-28">
      <div className="container">
        <div data-reveal>
          <span className="font-mono text-xs uppercase tracking-widest text-chalk/60">
            Curated Edits
          </span>
          <h2 className="mt-2 font-display text-3xl sm:text-4xl">
            Collections that tell a story.
          </h2>
        </div>

        <div className="mt-12 grid auto-rows-[280px] gap-4 lg:grid-cols-3 lg:grid-rows-2">
          {COLLECTIONS.map((collection, idx) => {
            const isFirst = idx === 0;
            return (
              <a
                key={collection.id}
                href={collection.href}
                data-reveal
                className={cn(
                  "group relative overflow-hidden",
                  isFirst && "lg:col-span-2 lg:row-span-2"
                )}
              >
                <img
                  src={collection.image}
                  alt={collection.name}
                  width={600}
                  height={400}
                  loading="lazy"
                  decoding="async"
                  className="absolute inset-0 h-full w-full object-cover transition-transform duration-500 ease-out group-hover:scale-105"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-ink/80 via-transparent to-transparent" />
                <div className="absolute inset-0 flex items-end p-6">
                  <div>
                    <h3 className="font-display text-xl text-chalk sm:text-2xl">
                      {collection.name}
                    </h3>
                    <p className="mt-2 font-mono text-xs uppercase tracking-widest text-chalk/70 transition-colors group-hover:text-chalk">
                      Shop the Edit →
                    </p>
                  </div>
                </div>
              </a>
            );
          })}
        </div>
      </div>
    </section>
  );
}
