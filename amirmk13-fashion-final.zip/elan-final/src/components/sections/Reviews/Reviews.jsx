import { StarIcon, CheckBadgeIcon } from "@/components/ui/icons";
import { useScrollReveal } from "@/hooks/useScrollReveal";
import { REVIEW_SUMMARY, REVIEWS } from "@/data/reviews";

function StarRow({ rating, size = 13 }) {
  return (
    <div className="flex gap-0.5">
      {[1, 2, 3, 4, 5].map((i) => (
        <StarIcon
          key={i}
          width={size}
          height={size}
          fill="currentColor"
          className={i <= rating ? "text-brass" : "text-ink/15"}
        />
      ))}
    </div>
  );
}

function ReviewCard({ review }) {
  return (
    <article data-reveal className="flex flex-col gap-3 border border-ink/10 p-5">
      <div className="flex items-center gap-3">
        <img
          src={review.avatar}
          alt=""
          width={40}
          height={40}
          loading="lazy"
          decoding="async"
          className="h-10 w-10 rounded-full object-cover"
        />
        <div>
          <p className="flex items-center gap-1 text-sm font-medium text-ink">
            {review.name}
            {review.verified && (
              <CheckBadgeIcon width={14} height={14} className="text-bottega" />
            )}
          </p>
          <p className="text-xs text-ink/50">{review.date}</p>
        </div>
      </div>

      <StarRow rating={review.rating} />

      <p className="text-sm leading-relaxed text-ink/80">{review.text}</p>

      {review.photo && (
        <img
          src={review.photo}
          alt="Customer-submitted photo of the product"
          width={120}
          height={120}
          loading="lazy"
          decoding="async"
          className="h-20 w-20 rounded-sm object-cover"
        />
      )}

      <p className="mt-auto font-mono text-[10px] uppercase tracking-widest text-ink/40">
        Purchased: {review.product}
      </p>
    </article>
  );
}

export default function Reviews() {
  const revealScope = useScrollReveal({ stagger: 0.08 });
  const { average, total, breakdown } = REVIEW_SUMMARY;

  return (
    <section ref={revealScope} className="bg-chalk py-20 sm:py-28">
      <div className="container">
        <div
          data-reveal
          className="flex flex-col gap-8 border-b border-ink/10 pb-10 sm:flex-row sm:items-center sm:justify-between"
        >
          <div className="flex items-center gap-4">
            <span className="font-display text-5xl">{average}</span>
            <div>
              <StarRow rating={Math.round(average)} size={14} />
              <p className="mt-1 text-xs text-ink/60">
                Based on {total.toLocaleString()} verified reviews
              </p>
            </div>
          </div>

          <div className="w-full max-w-sm space-y-1.5">
            {breakdown.map(({ star, percent }) => (
              <div key={star} className="flex items-center gap-2 text-xs text-ink/60">
                <span className="w-3">{star}</span>
                <div className="h-1.5 flex-1 overflow-hidden rounded-full bg-mist">
                  <div className="h-full rounded-full bg-brass" style={{ width: `${percent}%` }} />
                </div>
                <span className="w-8 text-right">{percent}%</span>
              </div>
            ))}
          </div>
        </div>

        <div className="mt-10 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {REVIEWS.map((review) => (
            <ReviewCard key={review.id} review={review} />
          ))}
        </div>
      </div>
    </section>
  );
}
