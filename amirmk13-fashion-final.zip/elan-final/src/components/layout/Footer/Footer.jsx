import { useScrollReveal } from "@/hooks/useScrollReveal";
import { InstagramIcon } from "@/components/ui/icons";
import { FOOTER_COLUMNS } from "@/data/footerLinks";

const PAYMENT_METHODS = ["Visa", "Mastercard", "Amex", "PayPal", "Apple Pay"];

export default function Footer() {
  const revealScope = useScrollReveal({ stagger: 0.06 });

  return (
    <footer ref={revealScope} className="bg-ink text-chalk">
      <div className="container py-16">
        <div data-reveal className="grid gap-10 sm:grid-cols-2 lg:grid-cols-[1.4fr_1fr_1fr_1fr]">
          <div>
            <p className="font-display text-2xl tracking-widest">ÉLAN</p>
            <p className="mt-3 max-w-xs text-sm text-chalk/60">
              Tailored essentials, made to outlast the season. Designed in
              our Lisbon atelier since 2014.
            </p>
            <a
              href="https://instagram.com"
              target="_blank"
              rel="noreferrer"
              aria-label="ÉLAN on Instagram"
              className="mt-5 inline-flex text-chalk/70 transition-colors hover:text-chalk"
            >
              <InstagramIcon width={20} height={20} />
            </a>
          </div>

          {FOOTER_COLUMNS.map((column) => (
            <div key={column.title}>
              <p className="font-mono text-[11px] uppercase tracking-widest text-chalk/50">
                {column.title}
              </p>
              <ul className="mt-4 space-y-2.5">
                {column.links.map((link) => (
                  <li key={link.label}>
                    <a
                      href={link.href}
                      className="text-sm text-chalk/75 transition-colors hover:text-chalk"
                    >
                      {link.label}
                    </a>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        <div
          data-reveal
          className="mt-12 flex flex-wrap gap-2 border-t border-chalk/10 pt-8"
        >
          {PAYMENT_METHODS.map((method) => (
            <span
              key={method}
              className="rounded-sm border border-chalk/20 px-3 py-1.5 font-mono text-[10px] uppercase tracking-widest text-chalk/60"
            >
              {method}
            </span>
          ))}
        </div>
      </div>

      <div className="border-t border-chalk/10 py-6">
        <div className="container flex flex-col gap-3 text-xs text-chalk/50 sm:flex-row sm:items-center sm:justify-between">
          <p>© {new Date().getFullYear()} ÉLAN Studio. All rights reserved.</p>
          <div className="flex gap-5">
            <a href="/privacy" className="hover:text-chalk/80">
              Privacy Policy
            </a>
            <a href="/terms" className="hover:text-chalk/80">
              Terms of Service
            </a>
            <a href="/accessibility" className="hover:text-chalk/80">
              Accessibility
            </a>
          </div>
        </div>
      </div>
    </footer>
  );
}
