import { useEffect, useRef } from "react";
import { useGSAP } from "@gsap/react";
import { gsap, prefersReducedMotion } from "@/animations/gsapConfig";
import { CloseIcon } from "@/components/ui/icons";

export default function MobileMenu({ open, onClose, links }) {
  const panelRef = useRef(null);
  const timelineRef = useRef(null);

  // Build the open/close timeline once and reuse it via play()/reverse().
  // This avoids creating new tweens (and GC pressure) on every toggle.
  useGSAP(
    () => {
      if (!panelRef.current) return;
      const items = panelRef.current.querySelectorAll("[data-menu-link]");
      const reduced = prefersReducedMotion();

      timelineRef.current = gsap
        .timeline({ paused: true })
        .fromTo(
          panelRef.current,
          { clipPath: "inset(0 0 100% 0)" },
          { clipPath: "inset(0 0 0% 0)", duration: reduced ? 0.01 : 0.5, ease: "power4.inOut" }
        )
        .fromTo(
          items,
          { yPercent: 30, opacity: 0 },
          { yPercent: 0, opacity: 1, duration: reduced ? 0.01 : 0.45, stagger: 0.06, ease: "power3.out" },
          "-=0.2"
        );
    },
    { scope: panelRef }
  );

  useEffect(() => {
    if (!timelineRef.current) return;
    document.body.style.overflow = open ? "hidden" : "";
    if (open) timelineRef.current.play();
    else timelineRef.current.reverse();
    return () => {
      document.body.style.overflow = "";
    };
  }, [open]);

  return (
    <div
      ref={panelRef}
      className={`fixed inset-0 z-40 flex flex-col bg-chalk px-6 pt-24 ${
        open ? "visible" : "invisible"
      }`}
      style={{ clipPath: "inset(0 0 100% 0)" }}
      role="dialog"
      aria-modal="true"
      aria-label="Site navigation"
    >
      <button
        onClick={onClose}
        aria-label="Close menu"
        className="absolute right-6 top-6 text-ink"
      >
        <CloseIcon width={26} height={26} />
      </button>

      <nav className="flex flex-col gap-1">
        {links.map((link) => (
          <div key={link.href} className="overflow-hidden">
            <a
              data-menu-link
              href={link.href}
              onClick={onClose}
              className={`block py-3 font-display text-3xl ${
                link.accent ? "text-rosewood" : "text-ink"
              }`}
            >
              {link.label}
            </a>
          </div>
        ))}
      </nav>
    </div>
  );
}
