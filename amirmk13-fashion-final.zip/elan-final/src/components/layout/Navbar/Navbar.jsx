import { useState, useContext } from 'react';
import { Link } from 'react-router-dom';
import { CartContext } from '@/context/CartContext';
import { WishlistContext } from '@/context/WishlistContext';
import { SearchIcon, HeartIcon, BagIcon, MenuIcon, CloseIcon } from '@/components/ui/icons';

export default function Navbar() {
  const [mobileOpen, setMobileOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const { cart } = useContext(CartContext);
  const { wishlist } = useContext(WishlistContext);
  const user = typeof window !== 'undefined' ? JSON.parse(localStorage.getItem('user') || 'null') : null;

  return (
    <nav className="sticky top-0 z-50 bg-chalk border-b border-ink/10">
      <div className="container flex items-center justify-between py-4">
        <Link to="/" className="font-display text-2xl font-bold text-ink">امیرام کالا</Link>

        <div className="hidden md:flex items-center gap-8">
          <Link to="/shop" className="text-sm hover:text-bottega">فروشگاه</Link>
          <Link to="/comparison" className="text-sm hover:text-bottega">مقایسه</Link>
          <Link to="/return-policy" className="text-sm hover:text-bottega">برگشت</Link>
          <Link to="/" className="text-sm hover:text-bottega">خانه</Link>
        </div>

        <div className="flex items-center gap-4">
          <form onSubmit={(e) => { e.preventDefault(); window.location.href = `/search?q=${searchQuery}`; }} className="hidden sm:flex items-center">
            <input type="text" placeholder="جستجو..." value={searchQuery} onChange={(e) => setSearchQuery(e.target.value)} className="p-2 border border-ink/20 rounded text-sm" />
          </form>

          <Link to={user ? '/account' : '/login'} className="p-2 hover:bg-ink/5 rounded text-sm">
            {user ? user.name : 'ورود'}
          </Link>

          <Link to="/account" className="p-2 hover:bg-ink/5 rounded relative">
            <HeartIcon width={20} height={20} />
            {wishlist.length > 0 && <span className="absolute top-1 right-1 bg-rosewood text-chalk text-xs rounded-full w-5 h-5 flex items-center justify-center">{wishlist.length}</span>}
          </Link>

          <Link to="/cart" className="p-2 hover:bg-ink/5 rounded relative">
            <BagIcon width={20} height={20} />
            {cart.length > 0 && <span className="absolute top-1 right-1 bg-rosewood text-chalk text-xs rounded-full w-5 h-5 flex items-center justify-center">{cart.length}</span>}
          </Link>

          <button onClick={() => setMobileOpen(!mobileOpen)} className="md:hidden p-2">
            {mobileOpen ? <CloseIcon width={20} height={20} /> : <MenuIcon width={20} height={20} />}
          </button>
        </div>
      </div>

      {mobileOpen && (
        <div className="md:hidden p-4 border-t space-y-2">
          <Link to="/shop" className="block py-2 text-sm">فروشگاه</Link>
          <Link to="/comparison" className="block py-2 text-sm">مقایسه</Link>
          <Link to="/return-policy" className="block py-2 text-sm">برگشت</Link>
        </div>
      )}
    </nav>
  );
}
