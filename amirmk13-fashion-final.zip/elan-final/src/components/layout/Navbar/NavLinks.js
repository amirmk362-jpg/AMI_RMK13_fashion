export const NAV_LINKS = [
  { label: "New In", href: "/new-in" },
  { label: "Women", href: "/women" },
  { label: "Men", href: "/men" },
  { label: "Collections", href: "/collections" },
  { label: "Sale", href: "/sale", accent: true },
];
