import { useRef } from "react";
import { useGSAP } from "@gsap/react";
import { gsap, registerGsap, prefersReducedMotion, onVisibilityChange } from "@/animations/gsapConfig";

registerGsap();

/**
 * Infinite horizontal scroll for a duplicated track. The track must be
 * rendered twice (back to back) by the caller so xPercent: -50 loops
 * seamlessly. Animates a single transform property — runs on the
 * compositor thread and stays cheap even on low-end mobile.
 */
export function useMarquee({ speed = 40 } = {}) {
  const trackRef = useRef(null);

  useGSAP(() => {
    if (!trackRef.current || prefersReducedMotion()) return;

    const distance = trackRef.current.scrollWidth / 2;
    const duration = distance / speed;

    const tween = gsap.to(trackRef.current, {
      xPercent: -50,
      duration,
      ease: "none",
      repeat: -1,
    });

    // Save CPU/battery when the tab is backgrounded.
    const stopWatching = onVisibilityChange((visible) => {
      if (visible) tween.resume();
      else tween.pause();
    });

    return () => {
      stopWatching();
      tween.kill();
    };
  }, { scope: trackRef });

  return trackRef;
}
