import { useRef } from "react";
import { useGSAP } from "@gsap/react";
import { gsap, registerGsap, prefersReducedMotion } from "@/animations/gsapConfig";

registerGsap();

/**
 * Fades + lifts any descendant marked with [data-reveal] into place as the
 * section scrolls into view. Animates only opacity + transform (no layout
 * properties), runs once per section, and snaps straight to the end state
 * under prefers-reduced-motion instead of skipping the reveal silently.
 */
export function useScrollReveal({ start = "top 80%", stagger = 0.12 } = {}) {
  const scope = useRef(null);

  useGSAP(
    () => {
      if (!scope.current) return;
      const targets = scope.current.querySelectorAll("[data-reveal]");
      if (!targets.length) return;

      if (prefersReducedMotion()) {
        gsap.set(targets, { opacity: 1, y: 0 });
        return;
      }

      gsap.set(targets, { opacity: 0, y: 32 });
      gsap.to(targets, {
        opacity: 1,
        y: 0,
        duration: 0.9,
        stagger,
        ease: "power3.out",
        scrollTrigger: {
          trigger: scope.current,
          start,
          once: true,
        },
      });
    },
    { scope }
  );

  return scope;
}
