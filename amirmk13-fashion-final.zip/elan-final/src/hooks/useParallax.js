import { useRef } from "react";
import { useGSAP } from "@gsap/react";
import { gsap, registerGsap, prefersReducedMotion } from "@/animations/gsapConfig";

registerGsap();

/**
 * Scrubs a single element's yPercent directly against scroll position
 * (scrub: true — no easing lag to manage) for a restrained parallax drift.
 * The element should be slightly oversized by its parent so the shift
 * never reveals empty edges. No-op under prefers-reduced-motion.
 */
export function useParallax({ amount = 12 } = {}) {
  const ref = useRef(null);

  useGSAP(
    () => {
      if (!ref.current || prefersReducedMotion()) return;

      gsap.fromTo(
        ref.current,
        { yPercent: -amount },
        {
          yPercent: amount,
          ease: "none",
          scrollTrigger: {
            trigger: ref.current,
            start: "top bottom",
            end: "bottom top",
            scrub: true,
          },
        }
      );
    },
    { scope: ref }
  );

  return ref;
}
