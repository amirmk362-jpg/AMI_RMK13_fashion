import { useRef } from "react";
import { useGSAP } from "@gsap/react";
import { gsap, registerGsap, prefersReducedMotion } from "@/animations/gsapConfig";

registerGsap();

/**
 * Animates any descendant marked with [data-reveal-line] up into view,
 * line by line. Pair each line with an `overflow-hidden` wrapper in markup
 * so the motion reads as a curtain reveal rather than a simple fade.
 *
 * Only transform (yPercent) is animated — no layout properties — so the
 * browser can run this entirely on the compositor thread.
 */
export function useTextReveal({ delay = 0, stagger = 0.09 } = {}) {
  const scope = useRef(null);

  useGSAP(
    () => {
      if (!scope.current) return;
      const lines = scope.current.querySelectorAll("[data-reveal-line]");
      if (!lines.length) return;

      if (prefersReducedMotion()) {
        gsap.set(lines, { opacity: 1, yPercent: 0 });
        return;
      }

      gsap.set(lines, { yPercent: 110 });
      gsap.to(lines, {
        yPercent: 0,
        duration: 1.1,
        ease: "power4.out",
        stagger,
        delay,
        force3D: true,
      });
    },
    { scope }
  );

  return scope;
}
