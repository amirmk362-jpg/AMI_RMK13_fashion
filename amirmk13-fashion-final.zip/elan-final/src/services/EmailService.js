export const EmailService = {
  sendWelcomeEmail: async (email, name) => {
    console.log(`Email sent to ${email}: Welcome`);
    return { success: true };
  },
  sendOrderConfirmation: async (email, orderId) => {
    console.log(`Email sent to ${email}: Order ${orderId}`);
    return { success: true };
  },
  sendShippingNotification: async (email, trackingId) => {
    console.log(`Email sent to ${email}: Shipping ${trackingId}`);
    return { success: true };
  }
};
