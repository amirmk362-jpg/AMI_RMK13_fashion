// Mock Backend API
export const ApiService = {
  // User API
  login: async (email, password) => {
    return { success: true, user: { email, name: 'User', token: 'mock-token' } };
  },
  register: async (name, email, password) => {
    return { success: true, user: { email, name, token: 'mock-token' } };
  },
  getProfile: async (userId) => {
    return { user: { id: userId, name: 'User', email: 'user@example.com' } };
  },
  updateProfile: async (userId, data) => {
    return { success: true, user: { ...data } };
  },

  // Products API
  getProducts: async (filters) => {
    return { success: true, products: [], total: 60 };
  },
  getProduct: async (slug) => {
    return { success: true, product: { slug, name: 'Product' } };
  },

  // Orders API
  createOrder: async (cartData) => {
    return { success: true, orderId: 'ORD-' + Date.now(), total: cartData.total };
  },
  getOrders: async (userId) => {
    return { success: true, orders: [] };
  },

  // Cart API
  saveCart: async (cartData) => {
    return { success: true };
  },
  loadCart: async (userId) => {
    return { success: true, cart: [] };
  }
};
