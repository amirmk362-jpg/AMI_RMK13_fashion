export const PaymentService = {
  initPayment: async (amount, description, email) => {
    return {
      success: true,
      authority: 'mock-' + Math.random().toString(36).substr(2, 9),
      paymentUrl: 'https://sandbox.zarinpal.com/mock-payment'
    };
  },
  verifyPayment: async (authority, amount) => {
    return {
      success: true,
      refId: 'ref-' + Math.random().toString(36).substr(2, 9)
    };
  }
};
