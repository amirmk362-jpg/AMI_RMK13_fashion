export const AnalyticsService = {
  trackEvent: (eventName, data) => console.log(`Event: ${eventName}`, data),
  trackPageView: (pageName) => console.log(`Page: ${pageName}`),
  trackAddToCart: (product) => console.log(`Cart: ${product.name}`),
  trackPurchase: (orderId, total) => console.log(`Purchase: ${orderId} - ${total}`)
};
