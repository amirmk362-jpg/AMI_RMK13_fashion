export const STORY_STATS = [
  { value: "2014", label: "Founded" },
  { value: "40+", label: "Countries Shipped" },
  { value: "92%", label: "Traceable Materials" },
];
