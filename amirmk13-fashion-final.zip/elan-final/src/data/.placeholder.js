// Generated product catalogue (60 items) is added in the products step.
