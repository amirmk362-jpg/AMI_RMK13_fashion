export const CATEGORIES = [
  { id: "cat-tshirts", name: "T-Shirts", image: "https://picsum.photos/seed/elan-cat1/240/240", href: "/category/t-shirts" },
  { id: "cat-hoodies", name: "Hoodies", image: "https://picsum.photos/seed/elan-cat2/240/240", href: "/category/hoodies" },
  { id: "cat-shirts", name: "Shirts", image: "https://picsum.photos/seed/elan-cat3/240/240", href: "/category/shirts" },
  { id: "cat-jeans", name: "Jeans", image: "https://picsum.photos/seed/elan-cat4/240/240", href: "/category/jeans" },
  { id: "cat-jackets", name: "Jackets", image: "https://picsum.photos/seed/elan-cat5/240/240", href: "/category/jackets" },
  { id: "cat-sneakers", name: "Sneakers", image: "https://picsum.photos/seed/elan-cat6/240/240", href: "/category/sneakers" },
  { id: "cat-watches", name: "Watches", image: "https://picsum.photos/seed/elan-cat7/240/240", href: "/category/watches" },
  { id: "cat-accessories", name: "Accessories", image: "https://picsum.photos/seed/elan-cat8/240/240", href: "/category/accessories" },
  { id: "cat-sportswear", name: "Sportswear", image: "https://picsum.photos/seed/elan-cat9/240/240", href: "/category/sportswear" },
  { id: "cat-formal", name: "Formal Wear", image: "https://picsum.photos/seed/elan-cat10/240/240", href: "/category/formal-wear" },
];
