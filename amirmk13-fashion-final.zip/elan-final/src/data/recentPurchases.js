export const RECENT_PURCHASES = [
  { id: 1, name: "Olivia from Toronto", product: "Tailored Wool Blazer", timeAgo: "2 minutes ago" },
  { id: 2, name: "Marcus from Berlin", product: "Automatic Steel Watch", timeAgo: "6 minutes ago" },
  { id: 3, name: "Aiko from Tokyo", product: "Minimal Leather Sneaker", timeAgo: "12 minutes ago" },
  { id: 4, name: "Liam from Dublin", product: "Waxed Field Jacket", timeAgo: "18 minutes ago" },
  { id: 5, name: "Priya from Mumbai", product: "Merino Crewneck Sweater", timeAgo: "24 minutes ago" },
];
