export const FAQS = [
  {
    id: "faq-shipping",
    question: "How long does shipping take?",
    answer:
      "Standard shipping arrives in 3–5 business days within the country of origin and 7–12 business days internationally. Express options are available at checkout for most regions.",
  },
  {
    id: "faq-returns",
    question: "What's your return policy?",
    answer:
      "You have 30 days from delivery to return any unworn item with tags attached for a full refund. Sale and Flash Sale items can be exchanged or returned for store credit.",
  },
  {
    id: "faq-sizing",
    question: "How do I find my size?",
    answer:
      "Every product page includes a size guide with body measurements for that specific style, since fit varies slightly across categories like denim, knitwear, and outerwear.",
  },
  {
    id: "faq-materials",
    question: "Where are your materials sourced from?",
    answer:
      "We work with a small group of mills in Portugal, Italy, and Japan, all audited annually. Material origin and certifications are listed on each product page under 'Composition'.",
  },
  {
    id: "faq-payment",
    question: "What payment methods do you accept?",
    answer:
      "We accept all major credit cards, PayPal, Apple Pay, and Google Pay. Installment payment plans are available at checkout in eligible regions.",
  },
  {
    id: "faq-authenticity",
    question: "How do I know a product is authentic?",
    answer:
      "Every ÉLAN item ships directly from our own atelier or authorized warehouses — we don't sell through third-party marketplaces, so authenticity is guaranteed on every order.",
  },
];
