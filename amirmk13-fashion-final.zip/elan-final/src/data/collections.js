export const COLLECTIONS = [
  {
    id: "tailoring-edit",
    tag: "Formal Wear & Outerwear",
    title: "The Tailoring Edit",
    image: "https://picsum.photos/seed/elan-c1/1000/1000",
    href: "/collections/tailoring",
  },
  {
    id: "street-layers",
    tag: "Hoodies & Sneakers",
    title: "Street Layers",
    image: "https://picsum.photos/seed/elan-c2/800/800",
    href: "/collections/street-layers",
  },
  {
    id: "after-hours",
    tag: "Eveningwear & Accessories",
    title: "After Hours",
    image: "https://picsum.photos/seed/elan-c3/800/800",
    href: "/collections/after-hours",
  },
];
