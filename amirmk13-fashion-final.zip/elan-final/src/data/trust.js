export const TRUST_BADGES = [
  { id: "secure", icon: "shield", label: "Secure SSL Checkout" },
  { id: "guarantee", icon: "check", label: "100% Authenticity Guaranteed" },
  { id: "returns", icon: "refresh", label: "30-Day Money-Back Guarantee" },
  { id: "shipping", icon: "truck", label: "Free Worldwide Shipping" },
];

export const TRUST_STATS = [
  { value: "250K+", label: "Happy Customers" },
  { value: "4.8/5", label: "Average Rating" },
  { value: "98%", label: "Satisfaction Rate" },
  { value: "150+", label: "Countries Served" },
];
