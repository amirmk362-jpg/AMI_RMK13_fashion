export const BLOG_POSTS = [
  {
    id: "blog-01",
    category: "Style Guides",
    title: "How to Build a Capsule Wardrobe in 10 Pieces",
    excerpt:
      "Fewer, better pieces that actually work together. Here's the exact framework our stylists use when building a season's capsule.",
    image: "https://picsum.photos/seed/elan-blog1/700/520",
    date: "May 28, 2026",
    readTime: "6 min read",
    href: "/journal/capsule-wardrobe",
  },
  {
    id: "blog-02",
    category: "Materials",
    title: "The Truth About Sustainable Denim",
    excerpt:
      "'Eco-friendly' gets thrown around loosely in denim. We break down what actually makes a pair of jeans more sustainable, and what's mostly marketing.",
    image: "https://picsum.photos/seed/elan-blog2/700/520",
    date: "May 14, 2026",
    readTime: "5 min read",
    href: "/journal/sustainable-denim",
  },
  {
    id: "blog-03",
    category: "Behind the Scenes",
    title: "Inside the Atelier: From Sketch to Sample",
    excerpt:
      "A look at the six-week process between a first sketch and an approved sample, including the fittings that almost never make a piece.",
    image: "https://picsum.photos/seed/elan-blog3/700/520",
    date: "April 30, 2026",
    readTime: "7 min read",
    href: "/journal/atelier-process",
  },
];
