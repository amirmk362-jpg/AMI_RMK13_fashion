import { TSHIRTS } from "./tshirts";
import { HOODIES } from "./hoodies";
import { SHIRTS } from "./shirts";
import { JEANS } from "./jeans";
import { JACKETS } from "./jackets";
import { SNEAKERS } from "./sneakers";
import { WATCHES } from "./watches";
import { ACCESSORIES } from "./accessories";
import { SPORTSWEAR } from "./sportswear";
import { FORMAL_WEAR } from "./formalWear";

export const PRODUCTS = [
  ...TSHIRTS,
  ...HOODIES,
  ...SHIRTS,
  ...JEANS,
  ...JACKETS,
  ...SNEAKERS,
  ...WATCHES,
  ...ACCESSORIES,
  ...SPORTSWEAR,
  ...FORMAL_WEAR,
];

// Quick access functions for filtering
export const getProductById = (id) => PRODUCTS.find((p) => p.id === id);
export const getProductBySlug = (slug) => PRODUCTS.find((p) => p.slug === slug);
export const getProductsByCategory = (category) =>
  PRODUCTS.filter((p) => p.category === category);
export const getBestSellers = () => PRODUCTS.filter((p) => p.bestSeller);
export const getNewArrivals = () => PRODUCTS.filter((p) => p.newArrival);
export const getTrending = () => PRODUCTS.filter((p) => p.trending);
export const getOnSale = () => PRODUCTS.filter((p) => p.discountPrice !== null);
