export const INSTAGRAM_POSTS = [
  { id: "ig-01", image: "https://picsum.photos/seed/elan-ig1/500/500", likes: 312, url: "https://instagram.com" },
  { id: "ig-02", image: "https://picsum.photos/seed/elan-ig2/500/500", likes: 248, url: "https://instagram.com" },
  { id: "ig-03", image: "https://picsum.photos/seed/elan-ig3/500/500", likes: 567, url: "https://instagram.com" },
  { id: "ig-04", image: "https://picsum.photos/seed/elan-ig4/500/500", likes: 189, url: "https://instagram.com" },
  { id: "ig-05", image: "https://picsum.photos/seed/elan-ig5/500/500", likes: 421, url: "https://instagram.com" },
  { id: "ig-06", image: "https://picsum.photos/seed/elan-ig6/500/500", likes: 298, url: "https://instagram.com" },
];
