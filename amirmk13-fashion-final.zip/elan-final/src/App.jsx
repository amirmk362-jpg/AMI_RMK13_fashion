import { Suspense } from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { CartProvider } from '@/context/CartContext';
import { WishlistProvider } from '@/context/WishlistContext';
import { CouponProvider } from '@/context/CouponContext';
import { DarkModeProvider } from '@/context/DarkModeContext';
import { LanguageProvider } from '@/context/LanguageContext';
import Navbar from '@/components/layout/Navbar';
import Footer from '@/components/layout/Footer';
import StyleGPT from '@/features/StyleGPT/StyleGPT';
import RecentPurchaseToast from '@/components/common/RecentPurchaseToast';
import Hero from '@/components/sections/Hero';
import PromoBanner from '@/components/sections/PromoBanner';
import BestSellers from '@/components/sections/BestSellers';
import NewArrivals from '@/components/sections/NewArrivals';
import Trending from '@/components/sections/Trending';
import FeaturedCollections from '@/components/sections/FeaturedCollections';
import FlashSale from '@/components/sections/FlashSale';
import Reviews from '@/components/sections/Reviews';
import BrandStory from '@/components/sections/BrandStory';
import FAQ from '@/components/sections/FAQ';
import Newsletter from '@/components/sections/Newsletter';
import InstagramGallery from '@/components/sections/InstagramGallery';
import Blog from '@/components/sections/Blog';
import FeaturedCategories from '@/components/sections/FeaturedCategories';
import TrustIndicators from '@/components/sections/TrustIndicators';
import ProductDetail from '@/pages/ProductDetail/ProductDetail';
import Shop from '@/pages/Shop/Shop';
import Cart from '@/pages/Cart/Cart';
import Checkout from '@/pages/Checkout/Checkout';
import Account from '@/pages/Account/Account';
import Search from '@/pages/Search/Search';
import Admin from '@/pages/Admin/Admin';
import Login from '@/pages/Auth/Login';
import Register from '@/pages/Auth/Register';
import Comparison from '@/features/Comparison/Comparison';
import ReturnPolicy from '@/pages/PolicyPages/ReturnPolicy';
import Analytics from '@/pages/Analytics/Analytics';

const LoadingFallback = () => <div className="min-h-screen flex items-center justify-center">در حال بارگذاری...</div>;

function HomePage() {
  return (
    <>
      <Hero />
      <PromoBanner />
      <BestSellers />
      <NewArrivals />
      <Trending />
      <FeaturedCollections />
      <FlashSale />
      <Reviews />
      <BrandStory />
      <FAQ />
      <Newsletter />
      <InstagramGallery />
      <Blog />
      <FeaturedCategories />
      <TrustIndicators />
    </>
  );
}

export default function App() {
  return (
    <DarkModeProvider>
      <LanguageProvider>
        <CartProvider>
          <WishlistProvider>
            <CouponProvider>
              <Router>
                <div className="min-h-screen bg-chalk font-body text-ink antialiased" dir="rtl">
                  <Navbar />
                  <Suspense fallback={<LoadingFallback />}>
                    <main>
                      <Routes>
                        <Route path="/" element={<HomePage />} />
                        <Route path="/product/:slug" element={<ProductDetail />} />
                        <Route path="/shop" element={<Shop />} />
                        <Route path="/cart" element={<Cart />} />
                        <Route path="/checkout" element={<Checkout />} />
                        <Route path="/account" element={<Account />} />
                        <Route path="/search" element={<Search />} />
                        <Route path="/admin" element={<Admin />} />
                        <Route path="/analytics" element={<Analytics />} />
                        <Route path="/login" element={<Login />} />
                        <Route path="/register" element={<Register />} />
                        <Route path="/comparison" element={<Comparison />} />
                        <Route path="/return-policy" element={<ReturnPolicy />} />
                      </Routes>
                    </main>
                  </Suspense>
                  <Footer />
                  <StyleGPT />
                  <RecentPurchaseToast />
                </div>
              </Router>
            </CouponProvider>
          </WishlistProvider>
        </CartProvider>
      </LanguageProvider>
    </DarkModeProvider>
  );
}
