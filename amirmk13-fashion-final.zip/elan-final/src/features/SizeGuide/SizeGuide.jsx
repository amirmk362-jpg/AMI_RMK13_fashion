export default function SizeGuide() {
  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
      <div className="bg-chalk rounded-lg p-8 max-w-2xl max-h-[90vh] overflow-y-auto">
        <h2 className="font-display text-2xl mb-6">راهنمای سایز</h2>
        
        <div className="space-y-6">
          <div>
            <h3 className="font-bold text-lg mb-3">تی‌شرت و پیراهن</h3>
            <table className="w-full text-sm border-collapse border border-ink/20">
              <tr className="bg-ink/5">
                <td className="border border-ink/20 p-2">XS</td>
                <td className="border border-ink/20 p-2">۳۲-۳۴</td>
                <td className="border border-ink/20 p-2">کوچک</td>
              </tr>
              <tr>
                <td className="border border-ink/20 p-2">S</td>
                <td className="border border-ink/20 p-2">۳۴-۳۶</td>
                <td className="border border-ink/20 p-2">کوچک</td>
              </tr>
              <tr className="bg-ink/5">
                <td className="border border-ink/20 p-2">M</td>
                <td className="border border-ink/20 p-2">۳۶-۳۸</td>
                <td className="border border-ink/20 p-2">متوسط</td>
              </tr>
              <tr>
                <td className="border border-ink/20 p-2">L</td>
                <td className="border border-ink/20 p-2">۳۸-۴۰</td>
                <td className="border border-ink/20 p-2">بزرگ</td>
              </tr>
              <tr className="bg-ink/5">
                <td className="border border-ink/20 p-2">XL</td>
                <td className="border border-ink/20 p-2">۴۰-۴۲</td>
                <td className="border border-ink/20 p-2">بسیار بزرگ</td>
              </tr>
            </table>
          </div>

          <div>
            <h3 className="font-bold text-lg mb-3">نکات مهم</h3>
            <ul className="list-disc list-inside space-y-2 text-sm">
              <li>اندازه‌گیری با لباس بر روی بدن انجام دهید</li>
              <li>اگر بین دو سایز هستید، سایز بزرگ‌تر را انتخاب کنید</li>
              <li>برند مختلف ممکن است سایز متفاوتی داشته باشد</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
}
