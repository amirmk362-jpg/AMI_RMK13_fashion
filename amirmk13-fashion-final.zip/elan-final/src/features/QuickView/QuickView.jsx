import { useState } from 'react';
import { StarIcon, HeartIcon } from '@/components/ui/icons';
import Button from '@/components/ui/Button';

export default function QuickView({ product, onClose }) {
  const [quantity, setQuantity] = useState(1);
  const [selectedColor, setSelectedColor] = useState(product.colors?.[0]);
  const [selectedSize, setSelectedSize] = useState(product.sizes?.[0]);

  if (!product) return null;

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
      <div className="bg-chalk rounded-lg w-full max-w-2xl max-h-[90vh] overflow-y-auto">
        <div className="sticky top-0 bg-chalk p-4 border-b flex justify-between items-center">
          <h2 className="font-display text-2xl">{product.name}</h2>
          <button onClick={onClose} className="text-2xl">✕</button>
        </div>

        <div className="p-6 grid grid-cols-1 gap-6 md:grid-cols-2">
          <div className="aspect-square overflow-hidden rounded bg-mist">
            <img src={product.images?.[0]} alt={product.name} className="h-full w-full object-cover" />
          </div>

          <div className="space-y-4">
            <div>
              <p className="text-ink/60 text-sm">{product.brand}</p>
              <p className="text-lg mt-2">{product.caption}</p>
            </div>

            <div className="flex items-center gap-2">
              {[...Array(5)].map((_, i) => (
                <StarIcon key={i} width={16} height={16} fill="currentColor" className={i < Math.round(product.rating) ? 'text-brass' : 'text-ink/20'} />
              ))}
              <span className="text-sm text-ink/60">({product.reviews})</span>
            </div>

            <div className="text-2xl font-bold">{(product.discountPrice || product.price).toLocaleString('fa-IR')} تومان</div>

            {product.colors?.length > 0 && (
              <div>
                <p className="text-sm font-bold mb-2">رنگ:</p>
                <div className="flex gap-2">
                  {product.colors.map((color) => (
                    <button key={color} onClick={() => setSelectedColor(color)} className={`w-8 h-8 rounded-full border-2 ${selectedColor === color ? 'border-ink' : 'border-transparent'}`} style={{backgroundColor: color}} />
                  ))}
                </div>
              </div>
            )}

            {product.sizes?.length > 0 && (
              <div>
                <p className="text-sm font-bold mb-2">سایز:</p>
                <div className="flex flex-wrap gap-2">
                  {product.sizes.map((size) => (
                    <button key={size} onClick={() => setSelectedSize(size)} className={`px-3 py-1 border-2 text-sm ${selectedSize === size ? 'border-ink bg-ink text-chalk' : 'border-ink/20'}`}>{size}</button>
                  ))}
                </div>
              </div>
            )}

            <div className="flex items-center gap-4 py-4 border-t border-b">
              <div className="flex items-center border">
                <button onClick={() => setQuantity(Math.max(1, quantity - 1))} className="px-3 py-2">−</button>
                <span className="px-3">{quantity}</span>
                <button onClick={() => setQuantity(quantity + 1)} className="px-3 py-2">+</button>
              </div>
              <Button variant="primary" className="flex-1">افزودن به سبد</Button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
