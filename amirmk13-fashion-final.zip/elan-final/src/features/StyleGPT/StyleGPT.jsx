import { useState, useRef, useEffect } from 'react';

const RESPONSES = [
  { keywords: ['سایز', 'اندازه'], reply: 'سایز شما چنده؟ بگید تا مناسب‌ترین محصول رو پیشنهاد بدم' },
  { keywords: ['رنگ'], reply: 'کدام رنگ را ترجیح می‌دهید؟ سرخ، آبی، یا سیاه؟' },
  { keywords: ['قیمت', 'ارزان'], reply: 'بودجه شما چقدره؟ تا محصول مناسب پیدا کنم' },
  { keywords: ['جدید', 'نو'], reply: 'جدیدترین کالکشن ما رو ببینید!' },
  { keywords: ['فروش', 'تخفیف'], reply: 'محصولات با تخفیف بیشتر در صفحه فروش موجود است' },
  { keywords: ['hello', 'سلام', 'درود'], reply: 'سلام! خوش آمدید به امیرام کالا. چطور می‌تونم کمکتون کنم؟' }
];

export default function StyleGPT() {
  const [messages, setMessages] = useState([
    { id: 1, text: 'سلام! من StyleGPT هستم. چطور می‌تونم کمکتون کنم؟', sender: 'bot' }
  ]);
  const [input, setInput] = useState('');
  const [isOpen, setIsOpen] = useState(false);
  const messagesEnd = useRef(null);

  useEffect(() => {
    messagesEnd.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const getResponse = (text) => {
    for (let resp of RESPONSES) {
      if (resp.keywords.some(kw => text.includes(kw))) {
        return resp.reply;
      }
    }
    return 'ببخشید، نفهمیدم. می‌تونید بیشتر توضیح بدید؟';
  };

  const handleSend = () => {
    if (!input.trim()) return;
    
    setMessages([...messages, { id: messages.length + 1, text: input, sender: 'user' }]);
    
    setTimeout(() => {
      setMessages(prev => [...prev, {
        id: prev.length + 1,
        text: getResponse(input),
        sender: 'bot'
      }]);
    }, 500);
    
    setInput('');
  };

  return (
    <>
      {!isOpen ? (
        <button
          onClick={() => setIsOpen(true)}
          className="fixed bottom-6 right-6 h-14 w-14 rounded-full bg-bottega text-chalk shadow-lg hover:bg-bottega/90 flex items-center justify-center text-2xl z-40"
        >
          💬
        </button>
      ) : (
        <div className="fixed bottom-6 right-6 w-80 h-96 bg-chalk border-2 border-bottega rounded-lg shadow-2xl flex flex-col z-40">
          <div className="bg-bottega text-chalk p-4 flex justify-between items-center rounded-t">
            <h3 className="font-bold">StyleGPT</h3>
            <button onClick={() => setIsOpen(false)} className="text-xl">✕</button>
          </div>

          <div className="flex-1 overflow-y-auto p-4 space-y-3">
            {messages.map(msg => (
              <div key={msg.id} className={`flex ${msg.sender === 'user' ? 'justify-end' : 'justify-start'}`}>
                <div className={`max-w-xs p-3 rounded-lg ${msg.sender === 'user' ? 'bg-bottega text-chalk' : 'bg-ink/10'}`}>
                  {msg.text}
                </div>
              </div>
            ))}
            <div ref={messagesEnd} />
          </div>

          <div className="p-3 border-t border-ink/10 flex gap-2">
            <input
              type="text"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyPress={(e) => e.key === 'Enter' && handleSend()}
              placeholder="پیام..."
              className="flex-1 p-2 border border-ink/20 rounded text-sm"
            />
            <button onClick={handleSend} className="px-4 py-2 bg-bottega text-chalk rounded font-bold">
              ارسال
            </button>
          </div>
        </div>
      )}
    </>
  );
}
