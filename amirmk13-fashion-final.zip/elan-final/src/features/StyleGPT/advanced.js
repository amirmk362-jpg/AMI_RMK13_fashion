// Advanced StyleGPT Logic
export const advancedStyleGPT = {
  recommendations: {
    outfit: (style) => `برای سبک ${style}، پیشنهاد می‌کنم یک ترکیب کلاسیک انتخاب کنید.`,
    size: (height, weight) => `بر اساس اندازه‌ی شما، سایز M مناسب است.`,
    color: (skinTone) => `برای پوست ${skinTone}، رنگ‌های گرم بهتر می‌آیند.`,
  },
  
  comparator: (product1, product2) => ({
    price: product1.price < product2.price ? product1.name : product2.name,
    quality: 'هر دو محصول کیفیت بالا دارند',
    recommendation: product1.rating > product2.rating ? product1.name : product2.name
  }),

  materialExplainer: {
    cotton: 'نسبی: پارچه‌ی طبیعی و تنفس‌پذیر',
    polyester: 'دوام بالا و رنگ پایدار',
    wool: 'گرم و مناسب برای فصل سرد',
    silk: 'لطیف و درخشان'
  }
};
