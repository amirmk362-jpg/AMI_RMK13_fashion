import { useContext, useState } from 'react';
import { PRODUCTS } from '@/data/products';

export default function Comparison() {
  const [selected, setSelected] = useState([]);

  const handleAdd = (product) => {
    if (selected.length < 4 && !selected.find(p => p.id === product.id)) {
      setSelected([...selected, product]);
    }
  };

  const handleRemove = (productId) => {
    setSelected(selected.filter(p => p.id !== productId));
  };

  return (
    <div className="min-h-screen bg-chalk py-10">
      <div className="container">
        <h1 className="font-display text-3xl mb-10">مقایسه محصولات</h1>

        <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
          <div className="space-y-4">
            <h3 className="font-bold">افزودن محصول</h3>
            <div className="space-y-2 max-h-[500px] overflow-y-auto">
              {PRODUCTS.slice(0, 10).map(p => (
                <button key={p.id} onClick={() => handleAdd(p)} disabled={selected.length >= 4 || selected.find(s => s.id === p.id)} className="block w-full text-left p-2 border border-ink/20 rounded hover:bg-ink/5 disabled:opacity-50 text-sm">
                  {p.name}
                </button>
              ))}
            </div>
          </div>

          {selected.map(product => (
            <div key={product.id} className="border border-ink/10 rounded p-4">
              <button onClick={() => handleRemove(product.id)} className="text-right w-full mb-2 text-sm text-rosewood">حذف</button>
              <img src={product.images?.[0]} alt={product.name} className="w-full aspect-square object-cover rounded mb-3" />
              <h3 className="font-bold text-sm mb-2">{product.name}</h3>
              <p className="text-sm mb-1"><strong>قیمت:</strong> {(product.discountPrice || product.price).toLocaleString('fa-IR')}</p>
              <p className="text-sm mb-1"><strong>امتیاز:</strong> {product.rating}</p>
              <p className="text-sm"><strong>موجودی:</strong> {product.stock}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
