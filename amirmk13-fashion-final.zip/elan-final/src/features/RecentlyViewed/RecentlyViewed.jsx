import { useState, useEffect } from 'react';
import { PRODUCTS } from '@/data/products';
import ProductCard from '@/components/ui/ProductCard';

export default function RecentlyViewed() {
  const [viewed, setViewed] = useState([]);

  useEffect(() => {
    const saved = localStorage.getItem('recentlyViewed');
    if (saved) setViewed(JSON.parse(saved));
  }, []);

  if (viewed.length === 0) {
    return <div className="text-center text-ink/60 py-10">محصولی مشاهده نشده است</div>;
  }

  return (
    <div>
      <h3 className="font-bold text-lg mb-4">محصولات دیده‌شده</h3>
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-4">
        {viewed.map(id => {
          const product = PRODUCTS.find(p => p.id === id);
          return product ? <ProductCard key={id} product={product} /> : null;
        })}
      </div>
    </div>
  );
}

export function addToRecentlyViewed(productId) {
  const saved = JSON.parse(localStorage.getItem('recentlyViewed') || '[]');
  const updated = [productId, ...saved.filter(id => id !== productId)].slice(0, 10);
  localStorage.setItem('recentlyViewed', JSON.stringify(updated));
}
